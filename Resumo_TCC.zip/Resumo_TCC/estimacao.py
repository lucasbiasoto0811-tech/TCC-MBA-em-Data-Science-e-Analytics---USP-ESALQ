"""Verossimilhanca penalizada para contagens, com offset explicito.

Poisson ou NB2 (Var Y = mu + alpha*mu^2); alpha NB2 e estimado juntamente
com beta, nao fixado em 1. Penalidades normalizadas por numero de celulas.
Os efeitos de grupos sao MAP gaussianos condicionais a lambdas escolhidos
na validacao. Nao sao estimativas REML nem integracao da verossimilhanca.
"""
from dataclasses import dataclass
import time
import numpy as np
import pandas as pd
from scipy import sparse, optimize, special, stats, linalg
from sklearn.preprocessing import OneHotEncoder, SplineTransformer


@dataclass
class Desenho:
    tipo: str
    nos: int = 6

    def fit(self, df):
        self.grupos = self.tipo.endswith('_GRUPOS')
        self.gam = self.tipo.startswith('GAM')
        self.cats = ['COD_TARIF', 'SEXO', 'IDADE', 'COD_GRUPO', 'ANO_STATUS']
        if not self.grupos:
            self.cats.append('REGIAO')
        self.encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=True,
                                     dtype=np.float64)
        self.encoder.fit(df[self.cats])
        self.nomes = ['intercepto'] + self.encoder.get_feature_names_out(self.cats).tolist()
        self.blocos = {'intercepto': (0, 1), 'categorias': (1, len(self.nomes))}
        # ANO_MODELO e medido por decadas: sem criar idade negativa para modelo 2021.
        known = df.ANO_NUM.dropna().to_numpy(float)
        self.ano_centro = float(np.median(known)) if len(known) else 2020.
        self.ano_min = float(known.min()) if len(known) else np.nan
        self.ano_max = float(known.max()) if len(known) else np.nan
        self.ano_ativo = len(np.unique(known)) >= 2
        self.spline = None
        if self.ano_ativo:
            if self.gam and len(np.unique(known)) >= 4:
                self.spline = SplineTransformer(n_knots=min(self.nos, len(np.unique(known))),
                    degree=3, knots='uniform', include_bias=True, extrapolation='constant')
                self.spline.fit(((known-self.ano_centro)/10).reshape(-1, 1))
                k = self.spline.n_features_out_
            else:
                k = 1
            start = len(self.nomes)
            self.nomes += [f'ANO_TERMO_{i}' for i in range(k)]
            self.blocos['ano'] = (start, len(self.nomes))
        self.re_enc = {}
        if self.grupos:
            for c in ['REGIAO', 'COD_MODELO']:
                enc = OneHotEncoder(handle_unknown='ignore', sparse_output=True,
                                    dtype=np.float64).fit(df[[c]])
                start = len(self.nomes)
                self.nomes += enc.get_feature_names_out([c]).tolist()
                self.blocos['grupo_'+c] = (start, len(self.nomes))
                self.re_enc[c] = enc
        return self

    def transform(self, df):
        parts = [sparse.csr_matrix(np.ones((len(df), 1))), self.encoder.transform(df[self.cats])]
        known = df.ANO_NUM.notna().to_numpy()
        x = (pd.to_numeric(df.ANO_NUM).astype(float).fillna(self.ano_centro).to_numpy()-self.ano_centro)/10
        if self.ano_ativo:
            b = self.spline.transform(x[:, None]) if self.spline is not None else x[:, None]
            b[~known] = 0.  # ausente nao recebe efeito de ano imputado
            parts.append(sparse.csr_matrix(b))
        for c, enc in self.re_enc.items():
            parts.append(enc.transform(df[[c]]))
        return sparse.hstack(parts, format='csr')

    def penalty(self, fixed, smooth, groups):
        # Ridge de todos os coeficientes, exceto intercepto: J tem estimativa finita.
        # Uma constante em um bloco redundante e identificada pela penalidade.
        if min(fixed, smooth, groups) <= 0:
            raise ValueError('Todos os lambdas devem ser estritamente positivos.')
        p = sparse.eye(len(self.nomes), format='lil') * fixed
        p[0, 0] = 0.
        if self.spline is not None:
            a, b = self.blocos['ano']
            d2 = np.diff(np.eye(b-a), n=2, axis=0)
            p[a:b, a:b] = smooth*(d2.T @ d2) + fixed*np.eye(b-a)
        for key, (a, b) in self.blocos.items():
            if key.startswith('grupo_'):
                p[a:b, a:b] = groups*sparse.eye(b-a)
        return p.tocsr()

    def novelty(self, df):
        out = []
        for c, cats in zip(self.cats, self.encoder.categories_):
            mask = ~df[c].isin(cats)
            out.append(dict(variavel=c, linhas_novas=int(mask.sum()),
                            exposicao_nova=float(df.loc[mask, 'E'].sum())))
        for c, enc in self.re_enc.items():
            mask = ~df[c].isin(enc.categories_[0])
            out.append(dict(variavel=c, linhas_novas=int(mask.sum()),
                            exposicao_nova=float(df.loc[mask, 'E'].sum())))
        if self.ano_ativo:
            m = df.ANO_NUM.lt(self.ano_min) | df.ANO_NUM.gt(self.ano_max)
            out.append(dict(variavel='ANO_FORA_SUPORTE', linhas_novas=int(m.sum()),
                            exposicao_nova=float(df.loc[m, 'E'].sum())))
        return out


def logpmf(y, mu, family, alpha=0.):
    if family == 'poisson':
        return special.xlogy(y, mu)-mu-special.gammaln(y+1)
    r = 1/alpha
    return (special.gammaln(y+r)-special.gammaln(r)-special.gammaln(y+1)
            -r*np.log1p(alpha*mu) + special.xlogy(y, alpha*mu)-y*np.log1p(alpha*mu))


def objective(theta, x, y, loge, p, family):
    nb = family == 'nb2'
    beta = theta[:-1] if nb else theta
    eta = loge + x @ beta
    with np.errstate(over='ignore', invalid='ignore'):
        mu = np.exp(eta)
    if not np.isfinite(mu).all() or (mu <= 0).any():
        return np.inf, np.zeros_like(theta)
    alpha = np.exp(theta[-1]) if nb else 0.
    ll = logpmf(y, mu, family, alpha)
    score = (mu-y)/(1+alpha*mu)
    pb = p @ beta
    grad = np.asarray(x.T @ score).ravel()/len(y)+pb
    val = -ll.mean()+0.5*beta @ pb
    if nb:
        r = 1/alpha
        dldr = (special.digamma(y+r)-special.digamma(r)-np.log1p(alpha*mu)
                +1-(r+y)/(r+mu))
        grad = np.r_[grad, r*dldr.mean()]
    return float(val), grad


@dataclass
class Ajuste:
    family: str
    beta: np.ndarray
    alpha: float
    success: bool
    message: str
    iterations: int
    gradient: float
    seconds: float
    alpha_boundary: bool

    def predict(self, x, exposure):
        eta = x @ self.beta + np.log(np.asarray(exposure))
        with np.errstate(over='raise', invalid='raise'):
            mu = np.exp(eta)
        if not np.isfinite(mu).all() or (mu <= 0).any():
            raise FloatingPointError('Predicao nao finita/positiva; modelo nao utilizavel.')
        return mu


def fit_count(x, y, exposure, penalty, family, maxiter=500):
    y, e = np.asarray(y, float), np.asarray(exposure, float)
    if len(y) == 0 or y.sum() <= 0 or np.any(e <= 0):
        raise ValueError('Ajuste exige exposicao positiva e algum sinistro no conjunto.')
    start = time.perf_counter()
    theta = np.zeros(x.shape[1]+int(family == 'nb2'))
    theta[0] = np.log(y.sum()/e.sum())
    if family == 'nb2':
        theta[-1] = np.log(1.)
    # Reparametrizacao numerica; NAO altera penalidade nem padroniza exposicao.
    mu0 = e*y.sum()/e.sum()
    w0 = mu0/(1+mu0) if family == 'nb2' else mu0
    diag = np.asarray(x.power(2).T @ w0).ravel()/len(y)+penalty.diagonal()
    scale = 1/np.sqrt(np.maximum(diag, 1e-12))
    if family == 'nb2':
        scale = np.r_[scale, 1.]
    def obj(t):
        val, grad = objective(t*scale, x, y, np.log(e), penalty, family)
        return val, grad*scale
    bounds = [(None, None)]*x.shape[1]+([(-12., 8.)] if family == 'nb2' else [])
    res = optimize.minimize(obj, theta/scale, method='L-BFGS-B', jac=True, bounds=bounds,
                            options=dict(maxiter=maxiter, ftol=1e-11, gtol=1e-6, maxls=50))
    actual = res.x*scale
    gradient = np.asarray(res.jac).copy()
    boundary = False
    if family == 'nb2':
        boundary = actual[-1] < -11.99 or actual[-1] > 7.99
        if actual[-1] < -11.99 and gradient[-1] > 0: gradient[-1] = 0
        if actual[-1] > 7.99 and gradient[-1] < 0: gradient[-1] = 0
    gmax = float(np.max(np.abs(gradient)))
    return Ajuste(family, actual[:-1] if family == 'nb2' else actual,
                  float(np.exp(actual[-1])) if family == 'nb2' else 0.,
                  bool(res.success and gmax < 1e-4), str(res.message), int(res.nit),
                  gmax, time.perf_counter()-start, bool(boundary))


def deviance(y, mu, alpha=0.):
    d = special.xlogy(y, y/mu)
    if alpha == 0:
        return 2*(d-y+mu)
    r = 1/alpha
    return 2*(d-(y+r)*np.log((y+r)/(mu+r)))


def metrics(y, e, mu, fit, edf=np.nan):
    y, e = np.asarray(y, float), np.asarray(e, float)
    v = mu+fit.alpha*mu**2
    dp = float(deviance(y, mu).sum())
    ll = float(logpmf(y, mu, fit.family, fit.alpha).sum())
    pearson = float(np.sum((y-mu)**2/v))
    pzero = np.exp(-mu) if fit.family == 'poisson' else np.exp(-np.log1p(fit.alpha*mu)/fit.alpha)
    return dict(n=len(y), exposicao=e.sum(), sinistros=y.sum(), previstos=mu.sum(),
        frequencia_observada=y.sum()/e.sum(), frequencia_prevista=mu.sum()/e.sum(),
        OE=y.sum()/mu.sum(), log_likelihood_condicional=ll, nll_por_celula=-ll/len(y),
        poisson_deviance_total=dp, poisson_deviance_por_exposicao=dp/e.sum(),
        deviance_familia=float(deviance(y, mu, fit.alpha).sum()), pearson=pearson,
        pearson_por_celula=pearson/len(y),
        dispersao_ajustada=pearson/(len(y)-edf) if np.isfinite(edf) and len(y)>edf else np.nan,
        RMSE_contagem=float(np.sqrt(np.mean((y-mu)**2))), MAE_contagem=float(np.mean(abs(y-mu))),
        RMSE_taxa_ponderada=float(np.sqrt(np.sum(e*(y/e-mu/e)**2)/e.sum())),
        MAE_taxa_ponderada=float(np.sum(e*abs(y/e-mu/e))/e.sum()),
        zeros_observados=int(np.sum(y == 0)), zeros_esperados=float(pzero.sum()),
        edf_condicional=edf, alpha_nb2=fit.alpha)


def covariance(x, mu, fit, penalty, max_columns):
    # Hessiana esperada para beta; alpha NB2 e lambdas condicionados.
    # Nao fornece incerteza de selecao, nem covariancia robusta por conglomerados.
    if x.shape[1] > max_columns:
        return None, np.nan, None
    w = mu/(1+fit.alpha*mu)
    h = (x.T @ x.multiply(w[:, None])).toarray()
    a = h+len(mu)*penalty.toarray()
    cf = linalg.cho_factor(a, lower=True)
    cov = linalg.cho_solve(cf, np.eye(a.shape[0]))
    influence = cov @ h
    return cov, float(np.trace(influence)), np.diag(influence)


def randomized_residuals(y, mu, fit, rng):
    if fit.family == 'poisson':
        low, high = stats.poisson.cdf(y-1, mu), stats.poisson.cdf(y, mu)
    else:
        r = 1/fit.alpha
        prob = r/(r+mu)
        low, high = stats.nbinom.cdf(y-1, r, prob), stats.nbinom.cdf(y, r, prob)
    u = low+(high-low)*rng.random(len(y))
    return stats.norm.ppf(np.clip(u, 1e-12, 1-1e-12))
