# %% 01 - Entradas e configuracao central
# Python 3.11. Edite somente config.json, ao lado deste arquivo.
# Execute no VSCode/Spyder ou: python 01_executar.py
from pathlib import Path
import argparse
from modelagem import executar

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--config', default=str(Path(__file__).with_name('config.json')))
    args, _ = p.parse_known_args()  # compativel com argumentos do console IPython
    executar(Path(args.config))
