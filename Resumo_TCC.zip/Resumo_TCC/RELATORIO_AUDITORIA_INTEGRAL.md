# Auditoria integral da frequência de colisão parcial — 2020

Fonte: auditoria_integral_20260926_201606_047045.zip. Referência principal:
GLM binomial negativo, cenário com J, população com EXPOSICAO1>0.

## Execução e reconciliação

O manifesto registra CONCLUIDO_RECONCILIADO, Python 3.11.0, 73,005 segundos,
nenhum parâmetro reestimado e nenhuma linha excluída nesta auditoria.
As 36 comparações com os resultados da modelagem conferem, dentro das tolerâncias
numéricas do script. Foram avaliadas 2.844.506 células no primeiro semestre e
3.244.940 no segundo (6.089.446 no total), para GLM e GAM NB2.
Essa concordância valida a reprodução dos cálculos, não a coerência atuarial da fonte.

## Concentração do erro quadrático

Contribuição dos maiores erros à soma integral de (Y-mu)^2 do GLM NB2:

| Maiores células por erro | 202001 | 202002 |
|---|---:|---:|
| 1 | 30,41% | 29,20% |
| 5 | 78,41% | 71,42% |
| 10 | 86,42% | 84,13% |
| 25 | 91,06% | 92,40% |
| 100 | 93,08% | 96,45% |

São proporções da soma dos erros quadráticos, não do próprio RMSE. O RMSE contém
uma raiz quadrada e não tem essa decomposição aditiva. O grupo das 100 maiores
células é selecionado pelo erro, depois da avaliação: serve para diagnóstico,
não para estabelecer uma regra de exclusão ou estimar desempenho em nova população.

No teste, as 100 maiores células por erro são todas SEXO=0 e IDADE=0.
No treino, 99 das 100 são desse cruzamento. Os mesmos códigos não identificam
pessoas nem contratos.

| Cruzamento SEXO=0 e IDADE=0 | 202001 | 202002 |
|---|---:|---:|
| Células | 98.062 | 113.946 |
| Participação nas células | 3,45% | 3,51% |
| Participação na exposição | 1,70% | 1,86% |
| Participação nos sinistros | 17,58% | 18,08% |
| Participação no erro quadrático | 96,56% | 97,95% |
| O/E | 0,8452 | 1,2479 |

No segundo semestre, 43 das 100 células estão na região 16 e 26 na região 7.
Isso descreve a lista selecionada; não é, isoladamente, teste de efeito regional.

A célula destacada na amostra anterior (ID_LINHA=408951 no teste, Y=206) responde
por cerca de 0,171% do erro quadrático integral. A participação de 89,4% era
exclusivamente na amostra de resíduos. A auditoria integral resolve essa incerteza.

## Casos prioritários de origem

| Período | ID_LINHA | COD_MODELO | Ano | Região | Sexo/idade | Y | E | mu GLM NB2 |
|---|---:|---|---:|---:|---|---:|---:|---:|
| 202001 | 968276 | 004473-3 | 2019 | 16 | 0/0 | 1.617 | 1,860274 | 3,247203 |
| 202001 | 2502662 | 004358-3 | 2019 | 16 | 0/0 | 907 | 0,915069 | 1,514517 |
| 202002 | 2451224 | 999999-9 | 2020 | 16 | 0/0 | 2.523 | 4,172603 | 7,935804 |
| 202002 | 1769978 | 003463-0 | 2020 | 16 | 0/0 | 341 | 0,101370 | 0,173852 |

ID_LINHA é o índice zero-based do registro lido pelo pandas, antes do filtro de
exposição; não presumir que seja o número físico da linha no editor de texto.

Existe um problema metodológico a resolver: não basta interpretar toda a
concentração como heterogeneidade legítima e esperar que splines ou uma família
mais flexível absorvam o padrão. Há razões contagem/exposição muito elevadas,
concentradas em informação cadastral ausente e regiões específicas. Isso exige
verificar a proveniência e a correspondência entre numerador e denominador.

O dicionário fornecido (DEFINICOES_AUTOSEG.pdf, seções Expostos e Variáveis do
Banco de Dados) define EXPOSICAO1 como veículos expostos e FREQ_SIN2 como
quantidade de sinistros de colisão parcial. O código atual seleciona essas
colunas, preserva o índice original e não multiplica linhas por um join de
sinistros. A auditoria recebida, entretanto, deriva da base já tratada.
Ainda não reproduzimos a leitura dos registros extremos a partir dos arquivos
originais completos, que permanecem na máquina do pesquisador.

Informação insuficiente para determinar se esses casos refletem dados válidos,
inconsistência de origem, diferença de classificação entre exposição e sinistro,
ou problema na importação. Não há base para afirmar que são erros da SUSEP,
fraude, risco individual extremo ou consequência de aceitação inadequada.
Nenhuma dessas hipóteses é uma conclusão deste relatório.

## Pequenas exposições e Pearson

No teste, a faixa 0<E<=0,01 contém 26.447 células, exposição total 123,9863,
606 sinistros observados e 8,4554 previstos. O/E=71,6705. Essa faixa responde
por 25,11% da soma dos resíduos Pearson ao quadrado, mas apenas cerca de
0,01% da soma dos erros quadráticos. No treino, sua contribuição ao Pearson
é 26,61%.

Isso mostra por que as métricas destacam problemas diferentes. Não autoriza
excluir exposições pequenas ou abandonar o offset. Tampouco prova que cada
registro com resíduo grande seja inválido. Diagnósticos de dispersão também
precisam considerar essas contribuições, em vez de usar apenas um número global.

## Comparação atual e calibração

A diferença pareada na soma da perda logarítmica (NLL GAM menos NLL GLM) é
+1.314,4598 no treino e +1.576,3365 no teste. Positivo significa perda maior
para o GAM atual. Os totais pareados abrangem todas as células e reproduzem
a diferença das tabelas globais. Não calculamos significância ou intervalo
com independência de células presumida.

A restrição dos nós uniformes do GAM e a assimetria das penalidades permanecem.
Assim, estes resultados comparam as implementações atuais, não demonstram uma
superioridade geral da classe GLM sobre GAM.

O cruzamento 0/0 concentra o erro quadrático, mas o déficit líquido de previsão
continua amplo: no teste, F e M respondem por 84,65% desse déficit. Portanto,
resolver a contribuição dos extremos não garante resolver a calibração temporal.
J continua no principal, com regularização; os zeros observados não são evidência
de risco verdadeiro nulo.

## Próximo passo concreto

O pacote inclui 04_conferir_origem.py e 04_celulas_verificar.csv, com 493 células:
235 de 202001 e 258 de 202002. A seleção reúne os top 100 por contagem, por
Pearson² e por erro quadrático do GLM NB2 em cada período, além de anos marcados
para revisão, eliminando apenas repetições na lista de investigação.
Não altera ou exclui linhas da base analítica.

O script confere o hash dos arquivos originais contra fontes.csv, extrai todas
as colunas em texto e compara chaves, contagens e exposições por conversão
independente com Decimal. A concordância confirmará a importação desses casos;
não validará automaticamente a coerência atuarial do conteúdo da fonte.

Depois dessa checagem, corrigir a parametrização do GAM usando treino, com
componente linear comparável e penalidade própria para curvatura. Selecionar
hiperparâmetros dentro de 202001 e documentar a reutilização exploratória de
202002. Manter J e categorias ausentes; nenhum descarte por resíduo foi autorizado
ou aplicado. Informação de ausência deve permanecer distinta do código literal 0.

## Rastreabilidade

Fontes diretas: manifesto_auditoria.json, reconciliacao.csv, resumo_integral.csv,
concentracao_extremos.csv, diagnosticos_integrais_por_grupo.csv, top_100_*,
comparacao_pareada_modelo_regiao.csv.gz e anos_para_revisao_SEM_EXCLUSAO.csv,
todos dentro do ZIP recebido. Campos derivados usam denominadores integrais
correspondentes ao mesmo período/modelo.
