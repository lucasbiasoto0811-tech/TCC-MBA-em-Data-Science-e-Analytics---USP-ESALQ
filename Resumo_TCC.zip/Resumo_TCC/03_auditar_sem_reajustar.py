"""Auditoria integral dos modelos JA ajustados — sem reestimar parametros.
Copie este arquivo para a pasta de 01_executar.py, estimacao.py e config.json.
Execute no mesmo Python/ambiente da modelagem. Nao altera arquivos existentes.
Saida: subpasta auditoria_integral_... + ZIP pronto para envio.
"""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import importlib.metadata
import json
import logging
import platform
import sqlite3
import sys
import time
import zipfile

import joblib
import numpy as np
import pandas as pd
from scipy import sparse, special
from threadpoolctl import threadpool_limits

# %% Configuracao — opcional: cole a pasta da execucao, nao a pasta dos dados brutos.
PASTA_EXECUCAO = ''  # Vazio: procura ultima execucao concluida usando config.json.
LINHAS_POR_BLOCO = 100_000
TOP_N = 100
MODELOS = ['principal_com_J_GLM_nb2', 'principal_com_J_GAM_nb2']
CHAVE = ['COD_TARIF','REGIAO','COD_MODELO','ANO_MODELO','SEXO','IDADE']
COLUNAS = CHAVE+['COD_GRUPO','ANO_NUM','ANO_STATUS','Y','E','ID_LINHA','PERIODO']
METRICAS = ['linhas','exposicao','observados','esperados','soma_y2','pearson2',
            'erro_quadratico','deviance_poisson','nll','zeros_obs','zeros_esp']


def salvar(df,path):
    df.to_csv(path,sep=';',decimal=',',index=False,encoding='utf-8-sig')


def hash_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def localizar(execucao=None):
    if execucao: return Path(execucao).expanduser().resolve()
    root=Path(__file__).resolve().parent
    cfg=json.loads((root/'config.json').read_text(encoding='utf-8'))
    out=Path(cfg['pasta_saida'])
    if not out.is_absolute():out=root/out
    for p in sorted(out.glob('execucao_*'),reverse=True):
        meta=p/'manifesto.json'
        if meta.exists() and json.loads(meta.read_text(encoding='utf-8')).get('status')=='CONCLUIDO_REVISAR_DIAGNOSTICOS':
            if (p/'base_tratada.sqlite').exists():return p
    raise FileNotFoundError('Nenhuma execucao concluida localizada. Preencha PASTA_EXECUCAO.')


def diagnosticos(y,e,mu,family,alpha):
    # Formulas independentes, conferidas contra as metricas da etapa 2.
    if np.any(~np.isfinite(mu)) or np.any(mu<=0): raise ValueError('Predicoes invalidas.')
    pearson2=(y-mu)**2/(mu+alpha*mu*mu)
    dp=2*(special.xlogy(y,y/mu)-y+mu)
    if family=='poisson':
        ll=special.xlogy(y,mu)-mu-special.gammaln(y+1)
        p0=np.exp(-mu)
    else:
        r=1/alpha
        ll=(special.gammaln(y+r)-special.gammaln(r)-special.gammaln(y+1)
             -r*np.log1p(alpha*mu)+special.xlogy(y,alpha*mu)-y*np.log1p(alpha*mu))
        p0=np.exp(-np.log1p(alpha*mu)/alpha)
    return pd.DataFrame({'linhas':np.ones(len(y),dtype=np.int64),'exposicao':e,
        'observados':y,'esperados':mu,'soma_y2':y*y,'pearson2':pearson2,
        'erro_quadratico':(y-mu)**2,'deviance_poisson':dp,'nll':-ll,
        'zeros_obs':(y==0).astype(np.int64),'zeros_esp':p0})


def reduzir(acc,keys,chunk):
    grouped=chunk.groupby(keys,observed=True,dropna=False)[METRICAS].sum()
    return grouped if acc is None else acc.add(grouped,fill_value=0)


def resumo(df):
    df=df.copy()
    df['OE']=df.observados/df.esperados
    df['taxa_observada']=df.observados/df.exposicao
    df['taxa_prevista']=df.esperados/df.exposicao
    df['RMSE_contagem']=np.sqrt(df.erro_quadratico/df.linhas)
    df['Pearson_por_celula']=df.pearson2/df.linhas
    df['NLL_por_celula']=df.nll/df.linhas
    df['deviance_poisson_por_exposicao']=df.deviance_poisson/df.exposicao
    return df


def executar(pasta,bloco=LINHAS_POR_BLOCO):
    pasta=Path(pasta).resolve()
    manifest=json.loads((pasta/'manifesto.json').read_text(encoding='utf-8'))
    if manifest.get('versao')!='0.2.0-modelagem-condicional':
        raise ValueError('Esta auditoria foi preparada para a versao 0.2.0. Revisar compatibilidade.')
    # Desserializar apenas com a classe original; nao trocar estimacao.py antes desta auditoria.
    import estimacao
    original=manifest.get('scripts',{}).get('estimacao.py')
    if original and hash_file(Path(estimacao.__file__))!=original:
        raise ValueError('estimacao.py difere do arquivo usado nos modelos. Restaure a versao original 0.2.0.')
    data=pasta/'base_tratada.sqlite'
    if not data.exists():raise FileNotFoundError(data)
    out=pasta/('auditoria_integral_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    out.mkdir()
    logger=logging.getLogger('auditoria_'+out.name);logger.setLevel(logging.INFO)
    fh=logging.FileHandler(out/'auditoria.log',encoding='utf-8');sh=logging.StreamHandler()
    for h in [fh,sh]:
        h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));logger.addHandler(h)
    bundles={tag:joblib.load(pasta/'modelos'/(tag+'.joblib')) for tag in MODELOS}
    referencia=pd.read_csv(pasta/'tabelas/comparacao_consolidada.csv',sep=';',decimal=',')
    dims={name:None for name in ['SEXO','IDADE','COD_TARIF','REGIAO','FAIXA_E','SEXO_IDADE','TOTAL']}
    aggs={tag:dims.copy() for tag in MODELOS}
    tops={(tag,period,crit):pd.DataFrame() for tag in MODELOS
          for period in ['202001','202002'] for crit in ['Y','pearson2','erro_quadratico']}
    suspicious=[];paired=[];started=time.perf_counter();status='EM_EXECUCAO'
    # SQLite e aberto em modo somente leitura. Nao depende do caminho dos CSVs originais.
    conn=sqlite3.connect(data.as_uri()+'?mode=ro',uri=True)
    try:
        with threadpool_limits(limits=2):
            for period in ['202001','202002']:
                count=0
                reader=pd.read_sql_query('SELECT '+','.join(COLUNAS)+' FROM celulas WHERE PERIODO=?',
                    conn,params=[period],chunksize=bloco)
                for df in reader:
                    df.ANO_NUM=pd.to_numeric(df.ANO_NUM,errors='raise').astype(float)
                    y,e=df.Y.to_numpy(float),df.E.to_numpy(float)
                    if np.any(e<=0):raise ValueError('Cache contem exposicao nao positiva.')
                    # Marcadores de revisao, NAO regras de exclusao/correcao.
                    review=df.ANO_NUM.lt(1900)|df.ANO_NUM.gt(2021)|df.ANO_NUM.isna()
                    if review.any():suspicious.append(df.loc[review].copy())
                    common={c:df[c].astype(str).to_numpy() for c in ['SEXO','IDADE','COD_TARIF','REGIAO']}
                    common['SEXO_IDADE']=df.SEXO.astype(str).str.cat(df.IDADE.astype(str),sep=' | ').to_numpy()
                    common['TOTAL']=np.repeat('TOTAL',len(df))
                    common['FAIXA_E']=pd.cut(e,[0,.01,.1,.5,1,10,100,np.inf],
                        labels=['(0;0,01]','(0,01;0,1]','(0,1;0,5]','(0,5;1]','(1;10]','(10;100]','>100']).astype(str)
                    losses={}
                    for tag,b in bundles.items():
                        design,fit=b['design'],b['fit']
                        x=design.transform(df) if design is not None else sparse.csr_matrix(np.ones((len(df),1)))
                        mu=fit.predict(x,e)
                        met=diagnosticos(y,e,mu,fit.family,fit.alpha)
                        losses[tag]=met.nll.to_numpy()
                        met['PERIODO']=period
                        for name,vals in common.items():
                            met['grupo']=vals
                            aggs[tag][name]=reduzir(aggs[tag][name],['PERIODO','grupo'],met)
                        candidates=df[CHAVE+['COD_GRUPO','ID_LINHA','E','Y','PERIODO']].copy()
                        candidates['mu']=mu
                        candidates['pearson2']=met.pearson2.to_numpy()
                        candidates['erro_quadratico']=met.erro_quadratico.to_numpy()
                        candidates['nll']=met.nll.to_numpy()
                        candidates['taxa_observada']=y/e
                        candidates['taxa_prevista']=mu/e
                        for crit in ['Y','pearson2','erro_quadratico']:
                            key=(tag,period,crit)
                            tops[key]=pd.concat([tops[key],candidates.nlargest(TOP_N,crit)],ignore_index=True).nlargest(TOP_N,crit)
                    # Diferenca pareada: positiva significa NLL maior (pior) no GAM.
                    pair=pd.DataFrame({'PERIODO':period,'COD_MODELO':df.COD_MODELO.astype(str),
                        'REGIAO':df.REGIAO.astype(str),'n':1,
                        'soma_diferenca_nll_GAM_menos_GLM':losses[MODELOS[1]]-losses[MODELOS[0]]})
                    paired.append(pair.groupby(['PERIODO','COD_MODELO','REGIAO'],observed=True).sum())
                    # Compacta acumuladores para manter uso de memoria limitado em muitos blocos.
                    if len(paired)>=5:
                        paired=[pd.concat(paired).groupby(level=[0,1,2]).sum()]
                    count+=len(df)
                    logger.info('%s: %d celulas auditadas; nenhum reajuste realizado.',period,count)
        allgroups=[];totals=[]
        for tag,by in aggs.items():
            for variable,dataframe in by.items():
                if dataframe is None:continue
                g=resumo(dataframe.reset_index());g['modelo']=tag;g['variavel']=variable
                allgroups.append(g)
                if variable=='TOTAL':totals.append(g)
        groups=pd.concat(allgroups,ignore_index=True)
        salvar(groups,out/'diagnosticos_integrais_por_grupo.csv')
        total=pd.concat(totals,ignore_index=True)
        salvar(total,out/'resumo_integral.csv')
        # Reconciliacao obrigatoria contra saidas anteriores; nao mascara divergencias.
        checks=[]
        for _,row in total.iterrows():
            model=row.modelo.removeprefix('principal_com_J_').removesuffix('_nb2')
            part='treino_202001' if row.PERIODO=='202001' else 'teste_202002'
            ref=referencia.loc[(referencia.cenario=='principal_com_J')&(referencia.modelo==model)
                &(referencia.familia=='nb2')&(referencia.particao==part)].iloc[0]
            for new,old in [('linhas','n'),('exposicao','exposicao'),('observados','sinistros'),
                ('esperados','previstos'),('pearson2','pearson'),('nll','log_likelihood_condicional'),
                ('zeros_esp','zeros_esperados'),('erro_quadratico','RMSE_contagem'),
                ('deviance_poisson','poisson_deviance_total')]:
                expected=-ref[old] if new=='nll' else ref[old]
                if new=='erro_quadratico':expected=ref.RMSE_contagem**2*ref.n
                actual=row[new];ok=bool(np.isclose(actual,expected,rtol=1e-7,atol=1e-5))
                checks.append(dict(modelo=row.modelo,periodo=row.PERIODO,metrica=new,
                                   recalculado=actual,anterior=expected,confere=ok))
        check=pd.DataFrame(checks);salvar(check,out/'reconciliacao.csv')
        contributions=[]
        for (tag,period,criterion),dataframe in tops.items():
            dataframe=dataframe.sort_values([criterion,'ID_LINHA'],ascending=[False,True])
            salvar(dataframe,out/f'top_{TOP_N}_{criterion}_{tag}_{period}.csv')
            tt=total.loc[(total.modelo==tag)&(total.PERIODO==period)].iloc[0]
            denominator={'Y':'observados','pearson2':'pearson2','erro_quadratico':'erro_quadratico'}[criterion]
            for k in [1,5,10,25,100]:
                contributions.append(dict(modelo=tag,periodo=period,criterio=criterion,top_n=k,
                    soma_top=float(dataframe.head(k)[criterion].sum()),soma_total=float(tt[denominator]),
                    proporcao=float(dataframe.head(k)[criterion].sum()/tt[denominator]) if tt[denominator]>0 else np.nan))
        salvar(pd.DataFrame(contributions),out/'concentracao_extremos.csv')
        if suspicious:
            years=pd.concat(suspicious,ignore_index=True)
            years['motivo_revisao']=np.select([years.ANO_NUM.lt(1900),years.ANO_NUM.gt(2021)],
                                            ['ano_anterior_1900','ano_posterior_2021'],default='ano_ausente_ou_especial')
        else:years=pd.DataFrame(columns=COLUNAS+['motivo_revisao'])
        salvar(years,out/'anos_para_revisao_SEM_EXCLUSAO.csv')
        pair=pd.concat(paired).groupby(level=[0,1,2]).sum().reset_index()
        pair['media_diferenca_nll_GAM_menos_GLM']=pair.soma_diferenca_nll_GAM_menos_GLM/pair.n
        salvar(pair,out/'comparacao_pareada_modelo_regiao.csv.gz')
        if not check.confere.all():raise ValueError('Reconciliacao divergiu. Envie a pasta de saida para revisao.')
        status='CONCLUIDO_RECONCILIADO'
        logger.info('Auditoria integral concluida e reconciliada.')
    except Exception:
        status='ERRO_REVISAR_LOG';logger.exception('Auditoria interrompida.');raise
    finally:
        conn.close()
        packages={p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','scikit-learn','joblib']}
        metadata=dict(status=status,python=platform.python_version(),bibliotecas=packages,
            modelos=MODELOS,linhas_por_bloco=bloco,top_n=TOP_N,segundos=time.perf_counter()-started,
            parametros_reestimados=False,linhas_excluidas_nesta_auditoria=0,
            script_sha256=hash_file(Path(__file__)),manifesto_origem_sha256=hash_file(pasta/'manifesto.json'),
            modelos_sha256={tag:hash_file(pasta/'modelos'/(tag+'.joblib')) for tag in MODELOS})
        (out/'manifesto_auditoria.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
        for h in [fh,sh]:h.close();logger.removeHandler(h)
    (out/'LEIA_RESULTADOS.txt').write_text('Auditoria de todos os registros, sem ajuste ou exclusao.\n'
        'Top-N e uma lista de investigacao, nao uma lista de exclusao.\n'
        'SEXO_IDADE e cruzamento de categorias, nao identidade de pessoa.\n'
        'Soma Y^2 mede concentracao das contagens, nao erro de predicao; erro_quadratico e distinto.\n'
        'Esquemas marginais se sobrepoem: nao somar contribuicoes de SEXO, IDADE e REGIAO.\n'
        'A diferenca pareada nao tem intervalo de confianca calculado nesta auditoria.\n'
        '202002 ja examinado: diagnostico exploratorio temporal, sem novo teste independente.\n',encoding='utf-8')
    zip_path=out.with_suffix('.zip')
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(out.iterdir()):
            if f.is_file():z.write(f,f.name)
    print('\nENVIE ESTE ARQUIVO:',zip_path)
    return out,zip_path


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--execucao',default=PASTA_EXECUCAO)
    a,_=p.parse_known_args()
    executar(localizar(a.execucao))
