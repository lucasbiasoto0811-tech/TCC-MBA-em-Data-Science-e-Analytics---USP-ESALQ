"""AUTOSEG: preparacao, EDA, GLM/GAM penalizados e avaliacao temporal.
Leia METODOLOGIA.md antes de interpretar qualquer resultado.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
from itertools import product
import gc
import hashlib
import importlib.metadata
import json
import logging
import platform
import sqlite3
import time
import warnings

import joblib
import numpy as np
import pandas as pd
from scipy import sparse, stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from threadpoolctl import threadpool_limits
from estimacao import (Desenho, fit_count, metrics, covariance, deviance,
                       logpmf, randomized_residuals)

VERSAO = '0.2.0-modelagem-condicional'
KEY = ['COD_TARIF', 'REGIAO', 'COD_MODELO', 'ANO_MODELO', 'SEXO', 'IDADE']
DIMS = ['auto_cat', 'auto_cau', 'auto_cep', 'auto_cidade', 'auto_cob',
        'auto_idade', 'auto_reg', 'auto_sexo', 'auto2_grupo', 'auto2_vei']
MISS = {'', 'NULL', 'NA', 'N/A', 'NAN'}
CAT = ['COD_TARIF', 'REGIAO', 'COD_MODELO', 'SEXO', 'IDADE', 'COD_GRUPO']


def csv(df, path):
    df.to_csv(path, sep=';', decimal=',', index=False, encoding='utf-8-sig')


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()


def encoding(path):
    try:
        with open(path, encoding='utf-8-sig') as f:
            while f.read(1024*1024): pass
        return 'utf-8-sig'
    except UnicodeDecodeError:
        return 'cp1252'


def code(s, integer=False):
    s = s.astype(str).str.strip()
    m = s.str.upper().isin(MISS)
    if integer:
        n = pd.to_numeric(s.str.replace(',', '.', regex=False), errors='coerce')
        ok = n.notna() & np.isfinite(n) & n.eq(np.floor(n)) & n.abs().lt(2**53)
        s.loc[ok] = n.loc[ok].astype('int64').astype(str)
    return s.mask(m, '__NULL__')


def numeric(s):
    s = s.str.strip()
    return pd.to_numeric(s.mask(s.str.upper().isin(MISS)).str.replace(',', '.', regex=False),
                         errors='coerce')


def load_dims(cfg, out):
    dims, audit = {}, []
    for name in DIMS:
        path = Path(cfg['pasta_dimensoes']) / (name+'.csv')
        d = pd.read_csv(path, sep=';', encoding=encoding(path), dtype=str, keep_default_na=False)
        d.columns = d.columns.str.strip()
        for c in d: d[c] = d[c].str.strip()
        key = {'auto_idade': 'codigo', 'auto_sexo': 'codigo', 'auto2_grupo': 'grpid'}.get(name, 'CODIGO')
        if key in d:
            d[key] = code(d[key], integer=name not in ['auto2_vei', 'auto_sexo'])
            if d[key].eq('__NULL__').any() or d[key].duplicated().any():
                raise ValueError(f'Chave ausente/duplicada na dimensao {name}.')
        if name == 'auto2_vei': d['COD_GRUPO'] = code(d.COD_GRUPO, integer=True)
        dims[name] = d
        audit.append(dict(arquivo=path.name, linhas=len(d), colunas=len(d.columns), sha256=sha(path)))
    if not dims['auto2_vei'].COD_GRUPO.isin(dims['auto2_grupo'].grpid).all():
        raise ValueError('Grupo veicular sem correspondencia em auto2_grupo.')
    if dims['auto_sexo'].set_index('codigo').loc['J'].iloc[0].strip() != 'Jurídica':
        raise ValueError('Revisar significado de J na dimensao antes da modelagem.')
    csv(pd.DataFrame(audit), out/'tabelas/dimensoes.csv')
    return dims


def prepare(cfg, out, dims, logger):
    """Leitura em blocos. Chave composta identifica celula, nunca pessoa/apolice."""
    conn = sqlite3.connect(out/'base_tratada.sqlite')
    resumo, qualidade, fontes, reservoir = [], Counter(), [], []
    maps = {'COD_TARIF': set(dims['auto_cat'].CODIGO), 'REGIAO': set(dims['auto_reg'].CODIGO),
            'SEXO': set(dims['auto_sexo'].codigo), 'IDADE': set(dims['auto_idade'].codigo),
            'COD_MODELO': set(dims['auto2_vei'].CODIGO)}
    vehicle = dims['auto2_vei'].set_index('CODIGO').COD_GRUPO.to_dict()
    rng = np.random.default_rng(cfg['seed'])
    for period, file in cfg['arquivos'].items():
        path = Path(cfg['pasta_dados']) / file
        enc = encoding(path)
        fontes.append(dict(periodo=period, arquivo=path.name, sha256=sha(path), encoding=enc))
        totals = Counter()
        local_sample = pd.DataFrame()
        reader = pd.read_csv(path, sep=';', encoding=enc, dtype=str, keep_default_na=False,
                             chunksize=cfg['linhas_por_bloco'])
        offset = 0
        for batch, raw in enumerate(reader, 1):
            raw.columns = raw.columns.str.strip()
            missing_cols = set(KEY+['FREQ_SIN2', 'EXPOSICAO1', 'ENVIO', 'PREMIO1', 'IS_MEDIA', 'INDENIZ2'])-set(raw)
            if missing_cols: raise ValueError(f'Colunas ausentes: {missing_cols}')
            y, e = numeric(raw.FREQ_SIN2), numeric(raw.EXPOSICAO1)
            bad = ~np.isfinite(y) | ~np.isfinite(e) | y.lt(0) | y.ne(np.floor(y))
            if bad.any():
                csv(raw.loc[bad].head(1000), out/f'tabelas/ERROS_ALVO_EXPOSICAO_{period}.csv')
                raise ValueError('Alvo/exposicao invalido. Nenhuma imputacao automatica; consulte ERROS.')
            if not cfg['modo_amostra']:
                if not raw.ENVIO.str.strip().eq(cfg['envio_esperado'][period]).all():
                    raise ValueError(f'ENVIO inesperado em {file}; revisar periodo/arquivo.')
            for c in raw:
                qualidade[(period, c, 'ausencias_literais')] += int(raw[c].str.strip().str.upper().isin(MISS).sum())
                qualidade[(period, c, 'linhas')] += len(raw)
                if c in ['FREQ_SIN2','EXPOSICAO1','PREMIO1','IS_MEDIA','INDENIZ2']:
                    nv = numeric(raw[c])
                    literal = raw[c].str.strip().str.upper().isin(MISS)
                    qualidade[(period, c, 'numericos_invalidos_nao_ausentes')] += int((~np.isfinite(nv) & ~literal).sum())
                    qualidade[(period, c, 'negativos')] += int(nv.lt(0).sum())
                    qualidade[(period, c, 'zeros')] += int(nv.eq(0).sum())
            totals['linhas_originais'] += len(raw)
            totals['sinistros_originais'] += float(y.sum())
            totals['linhas_e_nao_positiva'] += int(e.le(0).sum())
            totals['linhas_e_negativa'] += int(e.lt(0).sum())
            totals['sinistros_excluidos'] += float(y[e.le(0)].sum())
            z = pd.DataFrame(index=raw.index)
            for c in KEY:
                z[c] = code(raw[c], integer=c in ['COD_TARIF', 'REGIAO', 'IDADE', 'ANO_MODELO'])
            z['E'], z['Y'] = e, y
            # Guarda impacto das exclusoes por grupos antes de filtrar.
            for c in ['COD_TARIF', 'SEXO', 'IDADE']:
                g = z.assign(Y_EXCLUIDO=y.where(e.le(0), 0), EXCLUIDO=e.le(0).astype(int)).groupby(c, observed=True).agg(
                    linhas=('Y', 'size'), sinistros=('Y', 'sum'), excluidas=('EXCLUIDO', 'sum'),
                    sinistros_excluidos=('Y_EXCLUIDO', 'sum'))
                for level, row in g.iterrows():
                    for metric, value in row.items(): qualidade[(period, c+'='+level, metric)] += float(value)
            z['ID_LINHA'] = np.arange(offset, offset+len(raw), dtype=np.int64)
            offset += len(raw)
            z = z.loc[z.E.gt(0)].copy()
            if not len(z): continue
            for c, valid in maps.items():
                z[c+'_STATUS'] = np.where(z[c].eq('__NULL__'), 'NULL',
                    np.where(z[c].isin(valid), 'CODIGO_DOCUMENTADO', 'SEM_CORRESPONDENCIA'))
            z['COD_GRUPO'] = z.COD_MODELO.map(vehicle)
            z.loc[z.COD_MODELO.eq('__NULL__'), 'COD_GRUPO'] = '__NULL_MODELO__'
            z['COD_GRUPO'] = z.COD_GRUPO.fillna('__SEM_DIMENSAO__')
            # Nao converter faixa etaria em idade exata. Apenas ano com 4 digitos
            # entra como continuo; demais valores permanecem rastreaveis em ANO_STATUS.
            is_year = z.ANO_MODELO.str.fullmatch(r'\d{4}')
            z['ANO_NUM'] = pd.to_numeric(z.ANO_MODELO.where(is_year), errors='coerce')
            z['ANO_STATUS'] = np.where(is_year, 'ANO_4_DIGITOS', 'ESPECIAL_'+z.ANO_MODELO)
            # Estas medidas sao EDA, nao covariaveis preditivas principais.
            for c in ['PREMIO1', 'IS_MEDIA', 'INDENIZ2']:
                z[c] = numeric(raw.loc[z.index, c])
            z['PREMIO_MEDIO'] = z.PREMIO1/z.E
            z['PERIODO'] = period
            # Particao de celulas por chave, definida sem usar desfecho.
            z['FOLD'] = (pd.util.hash_pandas_object(z[KEY], index=False).to_numpy()%5).astype(int)
            z.to_sql('celulas', conn, if_exists='append', index=False, chunksize=5000)
            totals['linhas_mantidas'] += len(z)
            totals['sinistros_mantidos'] += float(z.Y.sum())
            totals['exposicao_mantida'] += float(z.E.sum())
            small = z.copy()
            small['_prioridade'] = rng.random(len(small))
            local_sample = pd.concat([local_sample, small], ignore_index=True).nsmallest(25000, '_prioridade')
            if batch % 5 == 0: logger.info('%s: %s linhas lidas', period, offset)
        resumo.append(dict(periodo=period, **totals))
        reservoir.append(local_sample)
        logger.info('%s concluido: %s', period, dict(totals))
    # Nao soma nem descarta duplicatas: bloqueia para revisar o significado da chave.
    keys = ','.join(['PERIODO']+KEY)
    duplicate = pd.read_sql_query(f'SELECT {keys}, COUNT(*) n FROM celulas GROUP BY {keys} HAVING COUNT(*)>1 LIMIT 1000', conn)
    csv(duplicate, out/'tabelas/duplicidades.csv')
    if len(duplicate):
        raise ValueError('Chave de celula duplicada; revisar antes de modelar.')
    conn.execute('CREATE INDEX idx_periodo ON celulas(PERIODO)')
    conn.commit()
    csv(pd.DataFrame(resumo), out/'tabelas/recorte.csv')
    csv(pd.DataFrame([dict(periodo=k[0], variavel=k[1], metrica=k[2], valor=v)
                      for k, v in qualidade.items()]), out/'tabelas/qualidade_exclusoes.csv')
    csv(pd.DataFrame(fontes), out/'tabelas/fontes.csv')
    sample = pd.concat(reservoir, ignore_index=True).drop(columns='_prioridade')
    csv(sample, out/'tabelas/amostra_descritiva_ate_25000_por_periodo.csv')
    return conn, sample


def savefig(fig, path):
    fig.tight_layout()
    fig.savefig(str(path)+'.png', dpi=250, bbox_inches='tight')
    fig.savefig(str(path)+'.pdf', bbox_inches='tight')
    plt.close(fig)


def eda(conn, sample, out):
    summary = pd.read_sql_query('''SELECT PERIODO, COUNT(*) n, SUM(Y) sinistros,
        SUM(E) exposicao, SUM(Y*Y) soma_y2, SUM(Y=0) zeros FROM celulas GROUP BY PERIODO''', conn)
    structure = pd.read_sql_query('''SELECT COD_MODELO, COUNT(*) celulas,
        COUNT(DISTINCT REGIAO) regioes, COUNT(DISTINCT COD_GRUPO) grupos,
        COUNT(DISTINCT PERIODO) periodos, SUM(E) exposicao, SUM(Y) sinistros
        FROM celulas GROUP BY COD_MODELO''', conn)
    csv(structure, out/'tabelas/estrutura_modelo_regiao.csv')
    summary['media_contagem'] = summary.sinistros/summary.n
    summary['variancia_contagem'] = (summary.soma_y2-summary.sinistros**2/summary.n)/(summary.n-1)
    summary['var_media_marginal'] = summary.variancia_contagem/summary.media_contagem
    csv(summary, out/'tabelas/dispersao_marginal.csv')
    for c in ['COD_TARIF', 'REGIAO', 'SEXO', 'IDADE', 'ANO_MODELO', 'COD_GRUPO', 'COD_MODELO']:
        g = pd.read_sql_query(f'''SELECT PERIODO, {c} grupo, COUNT(*) linhas,
            SUM(E) exposicao, SUM(Y) sinistros, AVG(Y) media_y, SUM(Y*Y) soma_y2,
            SUM(Y=0) zeros FROM celulas GROUP BY PERIODO, {c}''', conn)
        g['taxa'] = g.sinistros/g.exposicao
        g['variancia_y'] = (g.soma_y2-g.media_y**2*g.linhas)/(g.linhas-1).replace(0, np.nan)
        csv(g, out/f'tabelas/perfil_{c}.csv')
        if c not in ['COD_GRUPO', 'COD_MODELO', 'ANO_MODELO']:
            fig, ax = plt.subplots(figsize=(10, 4.5))
            pivot = g.pivot(index='grupo', columns='PERIODO', values='taxa')*100
            pivot.plot.bar(ax=ax)
            ax.set(xlabel=c, ylabel='Sinistros / 100 unidades de exposição', title=f'Frequência registrada por {c}')
            ax.tick_params(axis='x', labelsize=8)
            savefig(fig, out/f'figuras/eda_{c}')
    csv(sample[['Y','E','PREMIO1','PREMIO_MEDIO','IS_MEDIA','INDENIZ2','ANO_NUM']].describe(
        percentiles=[.01,.05,.25,.5,.75,.95,.99]).rename_axis('estatistica').reset_index(),
        out/'tabelas/descritiva_AMOSTRAL.csv')
    fig, axes = plt.subplots(2, 3, figsize=(12, 7))
    for ax, c in zip(axes.ravel(), ['Y','E','INDENIZ2','PREMIO_MEDIO','IS_MEDIA','ANO_NUM']):
        values = sample[c].replace([np.inf,-np.inf], np.nan).dropna().to_numpy(float)
        if c != 'ANO_NUM': values = np.sign(values)*np.log1p(abs(values))
        ax.hist(values, bins=40, color='#176b87')
        ax.set(title=c, ylabel='Células da amostra', xlabel='Valor' if c=='ANO_NUM' else 'sign(x) × log(1 + |x|)')
    fig.suptitle('Distribuições amostrais — transformação apenas dos eixos', y=1.03)
    savefig(fig, out/'figuras/eda_distribuicoes')
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
    for ax, c in zip(axes, ['E','PREMIO_MEDIO','IS_MEDIA']):
        v = sample[[c,'Y','E']].copy() if c!='E' else sample[['Y','E']].copy()
        vx = sample[c].to_numpy(float)
        ax.scatter(np.sign(vx)*np.log1p(abs(vx)), np.log1p(sample.Y/sample.E), s=3, alpha=.15)
        ax.set(xlabel=c+' (log com sinal)', ylabel='log(1 + Y/E)')
    savefig(fig, out/'figuras/eda_relacoes')
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.scatter(summary.media_contagem, summary.variancia_contagem)
    limit = max(summary.media_contagem.max(), summary.variancia_contagem.max())
    ax.plot([0,limit], [0,limit], '--', color='gray')
    ax.set(xlabel='Média marginal da contagem', ylabel='Variância marginal',
           title='Descritivo; exposição e covariáveis ainda não controladas')
    savefig(fig, out/'figuras/media_variancia_marginal')


def load_period(conn, period):
    # Carrega somente colunas de modelagem, mantendo categorias compactas.
    cols = CAT+['ANO_NUM', 'ANO_STATUS', 'Y', 'E', 'FOLD', 'ID_LINHA']
    frames = []
    for chunk in pd.read_sql_query('SELECT '+','.join(cols)+' FROM celulas WHERE PERIODO=?',
                                  conn, params=[period], chunksize=100000):
        frames.append(chunk)
    df = pd.concat(frames, ignore_index=True)
    del frames
    for c in CAT+['ANO_STATUS']: df[c] = df[c].astype('category')
    df['ANO_NUM'] = pd.to_numeric(df.ANO_NUM, errors='raise').astype(float)
    df['FOLD'] = df.FOLD.astype('int8')
    return df


def pick(df, n, seed):
    return df.sample(n=min(n, len(df)), random_state=seed).copy()


def parameters(cfg, kind):
    for fixed, smooth, groups in product(cfg['lambda_fixo'],
        cfg['lambda_smooth'] if kind.startswith('GAM') else [cfg['lambda_fixo'][0]],
        cfg['lambda_grupos'] if kind.endswith('_GRUPOS') else [cfg['lambda_fixo'][0]]):
        yield dict(fixed=float(fixed), smooth=float(smooth), groups=float(groups))


def tuning(train, cfg, out, scenario, logger):
    a = pick(train.loc[train.FOLD.ne(0)], cfg['limite_linhas_ajuste_interno'], cfg['seed'])
    b = pick(train.loc[train.FOLD.eq(0)], cfg['limite_linhas_validacao_interna'], cfg['seed']+1)
    if min(len(a), len(b)) < 20 or a.Y.sum() <= 0 or b.Y.sum() <= 0:
        raise ValueError('Amostra insuficiente para selecao interna; nao duplicar semestres para simular validacao.')
    records, chosen = [], []
    for kind in cfg['modelos']:
        design = Desenho(kind, cfg['nos_spline']).fit(a)
        x, xb = design.transform(a), design.transform(b)
        for family in cfg['familias']:
            valid = []
            for par in parameters(cfg, kind):
                penalty = design.penalty(**par)
                fit = fit_count(x, a.Y, a.E, penalty, family, cfg['maxiter'])
                row = dict(cenario=scenario, modelo=kind, familia=family, **par,
                           convergiu=fit.success, gradiente=fit.gradient, iteracoes=fit.iterations,
                           alpha_nb2=fit.alpha, alpha_no_limite=fit.alpha_boundary,
                           segundos=fit.seconds, n_ajuste=len(a), n_validacao=len(b), mensagem=fit.message)
                if fit.success:
                    mu = fit.predict(xb, b.E)
                    score = -logpmf(b.Y.to_numpy(), mu, family, fit.alpha).mean()
                    row['nll_validacao'] = score
                    row['deviance_poisson_por_exposicao'] = deviance(b.Y.to_numpy(), mu).sum()/b.E.sum()
                    valid.append((score, par))
                else:
                    row['nll_validacao'] = np.nan
                    logger.warning('Ajuste interno nao convergiu: %s %s %s', kind, family, par)
                records.append(row)
                csv(pd.DataFrame(records), out/f'tabelas/selecao_{scenario}.csv')
            if valid:
                score, par = min(valid, key=lambda z:z[0])
                chosen.append(dict(modelo=kind, familia=family, nll_validacao=score, **par))
                logger.info('Selecionado %s/%s/%s: %s', scenario, kind, family, par)
        del x, xb, design
        gc.collect()
    csv(pd.DataFrame(chosen), out/f'tabelas/selecionados_{scenario}.csv')
    return chosen


def calibrations(df, mu, cuts):
    rate = mu/df.E.to_numpy()
    result = []
    # Pontos de corte aprendidos no treino; empates ficam juntos, mesmo com <10 faixas.
    decile = np.searchsorted(cuts, rate, side='right')+1
    for c in ['TOTAL','DECIL_RISCO','REGIAO','COD_TARIF','SEXO','IDADE','COD_GRUPO']:
        key = np.repeat('TOTAL', len(df)) if c=='TOTAL' else (decile if c=='DECIL_RISCO' else df[c].to_numpy())
        q = pd.DataFrame({'grupo': key, 'exposicao': df.E.to_numpy(), 'observados': df.Y.to_numpy(),
                          'esperados':mu})
        g = q.groupby('grupo', observed=True, dropna=False).sum().reset_index()
        g['variavel'] = c
        g['OE'] = g.observados/g.esperados
        g['taxa_observada'] = g.observados/g.exposicao
        g['taxa_prevista'] = g.esperados/g.exposicao
        result.append(g)
    return pd.concat(result, ignore_index=True)


def weighted_cuts(rate, e):
    # Agrega empates antes de definir quantis ponderados por exposicao.
    q = pd.DataFrame({'rate':rate, 'e':e}).groupby('rate', sort=True).e.sum()
    cum = q.cumsum().to_numpy()/q.sum()
    idx = np.searchsorted(cum, np.arange(.1,1.,.1))
    return np.unique(q.index.to_numpy()[np.minimum(idx, len(q)-1)])


def predict_batches(design, fit, df, size=100000):
    mu = np.empty(len(df), dtype=float)
    for start in range(0, len(df), size):
        part = df.iloc[start:start+size]
        x = design.transform(part) if design else sparse.csr_matrix(np.ones((len(part),1)))
        mu[start:start+len(part)] = fit.predict(x, part.E)
    return mu


def diagnostics(df, mu, fit, design, cov, edf, diag_edf, out, tag, cfg, cuts):
    rng = np.random.default_rng(cfg['seed'])
    ii = np.sort(rng.choice(len(df), min(len(df),cfg['amostra_diagnosticos']), replace=False))
    d = df.iloc[ii]
    y, m = d.Y.to_numpy(float), mu[ii]
    pearson = (y-m)/np.sqrt(m+fit.alpha*m*m)
    rd = np.sign(y-m)*np.sqrt(np.maximum(deviance(y,m,fit.alpha), 0))
    rq = randomized_residuals(y,m,fit,rng)
    resid = pd.DataFrame({'ID_LINHA':d.ID_LINHA.to_numpy(), 'Y':y, 'E':d.E.to_numpy(),
                          'mu':m, 'Pearson':pearson, 'Deviance':rd, 'Quantil_aleatorizado':rq})
    if cov is not None:
        xs = design.transform(d) if design else sparse.csr_matrix(np.ones((len(d),1)))
        leverage = np.asarray(xs.multiply(xs @ cov).sum(axis=1)).ravel()*m/(1+fit.alpha*m)
        resid['leverage_local'] = leverage
        resid['Cook_aproximado'] = pearson**2*leverage/(edf*np.maximum(1-leverage,1e-10)**2)
    csv(resid, out/f'tabelas/residuos_AMOSTRA_{tag}.csv')
    fig, axes = plt.subplots(2,2,figsize=(10,8))
    axes[0,0].scatter(np.log1p(m), pearson, s=3, alpha=.15)
    axes[0,0].axhline(0,color='gray'); axes[0,0].set(xlabel='log(1 + contagem ajustada)',ylabel='Resíduo de Pearson')
    stats.probplot(rq, dist='norm', plot=axes[0,1])
    axes[0,1].set(title='QQ: resíduos quantílicos aleatorizados', xlabel='Quantis teóricos normais', ylabel='Resíduos quantílicos ordenados')
    cal = calibrations(df,mu,cuts)
    g = cal.loc[cal.variavel.eq('DECIL_RISCO')]
    axes[1,0].plot(g.grupo, g.taxa_observada, 'o-',label='Observada')
    axes[1,0].plot(g.grupo, g.taxa_prevista, 'o-',label='Prevista')
    axes[1,0].legend(); axes[1,0].set(xlabel='Faixa de risco (cortes do treino)',ylabel='Sinistros / exposição')
    axes[1,1].scatter(g.esperados,g.observados)
    lim = max(g.esperados.max(),g.observados.max()); axes[1,1].plot([0,lim],[0,lim],'--',color='gray')
    axes[1,1].set(xlabel='Sinistros previstos por faixa',ylabel='Sinistros observados por faixa')
    fig.suptitle(tag, fontsize=10)
    savefig(fig,out/f'figuras/diagnosticos_{tag}')
    return cal


def effects(design, fit, cov, diag_edf, out, tag):
    names = design.nomes if design else ['intercepto']
    table = pd.DataFrame({'termo':names,'coeficiente_penalizado':fit.beta})
    if cov is not None:
        se = np.sqrt(np.maximum(np.diag(cov),0))
        table['desvio_posterior_local_condicional'] = se
        table['limite_inferior_local_95'] = fit.beta-1.96*se
        table['limite_superior_local_95'] = fit.beta+1.96*se
        table['contribuicao_edf_condicional'] = diag_edf
    csv(table,out/f'tabelas/coeficientes_{tag}.csv')
    if design:
        contrasts=[]
        cursor=1
        for variable, levels in zip(design.cats, design.encoder.categories_):
            reference='M' if variable=='SEXO' and 'M' in levels else levels[0]
            reference_idx=cursor+list(levels).index(reference)
            for j,level in enumerate(levels):
                idx=cursor+j
                difference=fit.beta[idx]-fit.beta[reference_idx]
                row=dict(variavel=variable,nivel=str(level),referencia=str(reference),
                    log_razao_condicional=difference,razao_condicional=np.exp(difference),
                    interpretacao='Associacao ajustada; nao causal; coeficientes penalizados')
                if cov is not None:
                    variance=cov[idx,idx]+cov[reference_idx,reference_idx]-2*cov[idx,reference_idx]
                    error=np.sqrt(max(variance,0))
                    row['limite_local_95_inferior']=np.exp(difference-1.96*error)
                    row['limite_local_95_superior']=np.exp(difference+1.96*error)
                contrasts.append(row)
            cursor+=len(levels)
        csv(pd.DataFrame(contrasts),out/f'tabelas/contrastes_{tag}.csv')
        if diag_edf is not None:
            csv(pd.DataFrame([dict(bloco=k,edf_condicional=float(diag_edf[a:b].sum()))
                for k,(a,b) in design.blocos.items()]),out/f'tabelas/edf_blocos_{tag}.csv')
    if not design or not design.ano_ativo: return
    grid = np.linspace(design.ano_min,design.ano_max,100)
    values = (grid-design.ano_centro)/10
    basis = design.spline.transform(values[:,None]) if design.spline is not None else values[:,None]
    a,b = design.blocos['ano']
    # Curva relativa ao ano central; remove componente constante nao identificavel isoladamente.
    ref = design.spline.transform(np.zeros((1,1))) if design.spline is not None else np.zeros((1,1))
    contrast = basis-ref
    curve = contrast @ fit.beta[a:b]
    tab = pd.DataFrame({'ANO_MODELO':grid,'log_razao_relativa_ano_central':curve,'razao':np.exp(curve)})
    fig,ax = plt.subplots(figsize=(7,4))
    ax.plot(grid,np.exp(curve),color='#176b87')
    if cov is not None:
        se = np.sqrt(np.maximum(np.einsum('ij,jk,ik->i',contrast,cov[a:b,a:b],contrast),0))
        tab['limite_local_95_inferior']=np.exp(curve-1.96*se)
        tab['limite_local_95_superior']=np.exp(curve+1.96*se)
        ax.fill_between(grid,tab.limite_local_95_inferior,tab.limite_local_95_superior,alpha=.2)
    ax.axhline(1,color='gray',ls='--')
    ax.set(xlabel='Ano do modelo',ylabel=f'Razão relativa a {design.ano_centro:g}',title='Efeito parcial condicional — '+tag)
    savefig(fig,out/f'figuras/ano_parcial_{tag}')
    csv(tab,out/f'tabelas/ano_parcial_{tag}.csv')


def compare_models(train, test, cfg, out, scenario, chosen, logger):
    rows=[]
    specs=[dict(modelo='NULO',familia=f,nll_validacao=np.nan) for f in cfg['familias']]+chosen
    for spec in specs:
        kind,family=spec['modelo'],spec['familia']
        tag=f'{scenario}_{kind}_{family}'
        logger.info('Ajuste completo: %s, %d celulas',tag,len(train))
        design=None if kind=='NULO' else Desenho(kind,cfg['nos_spline']).fit(train)
        x=sparse.csr_matrix(np.ones((len(train),1))) if design is None else design.transform(train)
        p=sparse.csr_matrix((1,1)) if design is None else design.penalty(**{k:spec[k] for k in ['fixed','smooth','groups']})
        fit=fit_count(x,train.Y,train.E,p,family,cfg['maxiter'])
        if not fit.success:
            logger.warning('Repetindo %s com maior limite de iteracoes.',tag)
            fit=fit_count(x,train.Y,train.E,p,family,2*cfg['maxiter'])
        status=dict(cenario=scenario,modelo=kind,familia=family,convergiu=fit.success,
                    gradiente=fit.gradient,iteracoes=fit.iterations,mensagem=fit.message,
                    segundos_ajuste=fit.seconds,alpha_nb2=fit.alpha,alpha_no_limite=fit.alpha_boundary)
        (out/f'modelos/{tag}_status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
        if not fit.success:
            logger.error('Modelo excluido da comparacao: nao convergiu %s',tag)
            rows.append(dict(**status,particao='NAO_CONVERGIU'))
            continue
        mutrain=fit.predict(x,train.E)
        cov,edf,diag_edf=covariance(x,mutrain,fit,p,cfg['max_colunas_covariancia'])
        if cov is None:
            logger.info('%s: EDF/intervalos nao calculados por limite de memoria (%d colunas).',tag,x.shape[1])
        cuts=weighted_cuts(mutrain/train.E.to_numpy(),train.E.to_numpy())
        parcount=x.shape[1]+int(family=='nb2')
        formula='log(mu)=log(EXPOSICAO1)+intercepto'
        if design:
            formula+='+'+'+'.join(design.cats)+'+'+('s(ANO_MODELO)' if design.spline else 'ANO_MODELO')
            if design.grupos: formula+='+u(REGIAO)+v(COD_MODELO) [MAP condicional]'
        effects(design,fit,cov,diag_edf,out,tag)
        joblib.dump(dict(design=design,fit=fit,cuts=cuts,spec=spec,formula=formula),out/f'modelos/{tag}.joblib')
        if design:
            csv(pd.DataFrame(design.novelty(test)),out/f'tabelas/novos_niveis_{tag}.csv')
        for partition,df,mu in [('treino_202001',train,mutrain),
                                ('teste_202002',test,predict_batches(design,fit,test))]:
            m=metrics(df.Y,df.E,mu,fit,edf if partition.startswith('treino') else np.nan)
            # Criterios apenas condicionais/heuristicos. Nao sao AIC/BIC marginais GLMM.
            k_eff=edf+int(family=='nb2')
            aic=-2*m['log_likelihood_condicional']+2*k_eff if partition.startswith('treino') else np.nan
            bic=-2*m['log_likelihood_condicional']+np.log(len(df))*k_eff if partition.startswith('treino') else np.nan
            row=dict(**status,**{k:v for k,v in m.items() if k!='alpha_nb2'},particao=partition,
                formula=formula,link='log',n_coeficientes=parcount,nll_validacao=spec['nll_validacao'],
                AIC_condicional_aproximado=aic,BIC_condicional_aproximado=bic,
                lambda_fixo=spec.get('fixed',0),lambda_smooth=spec.get('smooth',0),lambda_grupos=spec.get('groups',0))
            rows.append(row)
            # Leverage/influencia sao definidos no treino, nao no teste.
            cal=diagnostics(df,mu,fit,design,cov if partition.startswith('treino') else None,
                            edf,diag_edf,out,tag+'_'+partition,cfg,cuts)
            csv(cal,out/f'tabelas/calibracao_{tag}_{partition}.csv')
            if partition.startswith('teste') and design:
                new=np.zeros(len(df),dtype=bool)
                for c,levels in zip(design.cats,design.encoder.categories_):
                    new |= ~df[c].isin(levels).to_numpy()
                for c,enc in design.re_enc.items():
                    new |= ~df[c].isin(enc.categories_[0]).to_numpy()
                support=[]
                for label,mask in [('TODOS_NIVEIS_CONHECIDOS',~new),('ALGUM_NIVEL_NOVO',new)]:
                    if mask.any():
                        met=metrics(df.Y.to_numpy()[mask],df.E.to_numpy()[mask],mu[mask],fit)
                        support.append(dict(suporte=label,**met))
                csv(pd.DataFrame(support),out/f'tabelas/generalizacao_niveis_{tag}.csv')
            if cfg['salvar_predicoes_celulas']:
                pred=pd.DataFrame({'ID_LINHA':df.ID_LINHA,'Y':df.Y,'E':df.E,'mu':mu,'taxa_prevista':mu/df.E})
                csv(pred,out/f'predicoes/{tag}_{partition}.csv.gz')
        csv(pd.DataFrame(rows),out/f'tabelas/comparacao_{scenario}.csv')
        del x,p,mutrain,cov,design
        gc.collect()
    return rows


def final_report(rows,out,cfg):
    df=pd.DataFrame(rows)
    csv(df,out/'tabelas/comparacao_consolidada.csv')
    valid=df.loc[df.particao.eq('teste_202002')].copy()
    if len(valid):
        for scenario,q in valid.groupby('cenario'):
            q=q.assign(rotulo=q.modelo+' / '+q.familia).set_index('rotulo')
            fig,axes=plt.subplots(1,3,figsize=(14,5))
            for ax,c in zip(axes,['nll_por_celula','poisson_deviance_por_exposicao','OE']):
                q[c].plot.barh(ax=ax,color='#176b87'); ax.set(title=c,ylabel='')
            savefig(fig,out/f'figuras/comparacao_{scenario}')
    lines=['# Execucao AUTOSEG — resultados condicionais', '',
        f'Versao: {VERSAO}. Modo amostra: {cfg["modo_amostra"]}.', '',
        'J mantido no principal. Nao interpretar zeros de J como ausencia real de risco.',
        'Nenhuma conclusao automatica de superioridade GLM/GAM foi escrita.',
        'Consulte comparacao_consolidada.csv, logs e todos os arquivos de status.',
        'A selecao de lambdas usa somente a particao interna de 202001. 202002 nao escolhe lambdas.',
        'A auditoria ja examinou marginais de ambos os semestres: teste temporal nao foi totalmente cego.',
        'NB2 nao prova adequacao; residuos, zeros e calibracao podem continuar inadequados.',
        'MAP de grupos nao substitui inferencia marginal/REML. ICC e variancias populacionais nao estimados.',
        'EDF e intervalos locais ficam ausentes quando o limite de colunas e ultrapassado.',
        'Intervalos condicionados a lambdas/alpha nao corrigem selecao nem dependencia residual.',
        'Nao comparar AIC/deviance bruta entre principal e sensibilidade: populacoes diferentes.',
        'O modelo nao estima o risco total removido por exclusao de celulas sem exposicao.', '',
        '## Proxima revisao', '',
        'Enviar tabelas/comparacao_consolidada.csv, selecionados_*.csv, selecao_*.csv,',
        'tabelas/recorte.csv, execucao.log e as figuras de diagnostico dos candidatos.',
        'Avaliacao formal de inflacao de zeros/hurdle requer mecanismo e diagnostico condicional;',
        'nao e ativada por alta proporcao marginal de zeros. Nao ha esses modelos nesta versao.',
        'Validacao de grupos inteiramente novos e bootstrap com reajuste permanecem extensoes.',
        'Este pacote e uma primeira comparacao executavel; a inferencia final do TCC depende da revisao.']
    (out/'LEIA_RESULTADOS.md').write_text('\n'.join(lines),encoding='utf-8')


def executar(config_path):
    config_path=Path(config_path).resolve()
    cfg=json.loads(config_path.read_text(encoding='utf-8'))
    for name in ['pasta_dados','pasta_dimensoes','pasta_saida']:
        p=Path(cfg[name])
        cfg[name]=str(p if p.is_absolute() else config_path.parent/p)
    out=Path(cfg['pasta_saida'])/datetime.now().strftime('execucao_%Y%m%d_%H%M%S_%f')
    for p in ['tabelas','figuras','modelos','predicoes']: (out/p).mkdir(parents=True,exist_ok=True)
    logger=logging.getLogger('autoseg_'+out.name)
    logger.setLevel(logging.INFO)
    fh=logging.FileHandler(out/'execucao.log',encoding='utf-8')
    sh=logging.StreamHandler()
    for handler in [fh,sh]:
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(handler)
    versions={}
    for package in ['numpy','pandas','scipy','scikit-learn','matplotlib','joblib','threadpoolctl']:
        versions[package]=importlib.metadata.version(package)
    manifest=dict(versao=VERSAO,python=platform.python_version(),bibliotecas=versions,
                  configuracao=cfg,inicio_utc=datetime.now(timezone.utc).isoformat(),status='INICIADO',
                  scripts={p.name:sha(p) for p in Path(__file__).resolve().parent.glob('*.py')})
    (out/'manifesto.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    conn=None
    started=time.perf_counter()
    try:
        with threadpool_limits(limits=cfg['threads']), warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            dims=load_dims(cfg,out)
            conn,sample=prepare(cfg,out,dims,logger)
            eda(conn,sample,out)
            del sample
            train=load_period(conn,'202001')
            test=load_period(conn,'202002')
            if not len(train) or not len(test): raise ValueError('Os dois semestres precisam de celulas validas.')
            # Especiais do ano ficam como categoria adicional em vez de desaparecerem.
            # A coluna e mantida para auditoria; status de ausencia entra no desenho.
            logger.info('Treino: %s; teste: %s. Inicio da selecao interna.',len(train),len(test))
            allrows=[]
            for scenario in cfg['cenarios']:
                if scenario not in ['principal_com_J','sensibilidade_sem_J']: raise ValueError(scenario)
                a=train if scenario=='principal_com_J' else train.loc[train.SEXO.ne('J')].copy()
                b=test if scenario=='principal_com_J' else test.loc[test.SEXO.ne('J')].copy()
                chosen=tuning(a,cfg,out,scenario,logger)
                allrows.extend(compare_models(a,b,cfg,out,scenario,chosen,logger))
                final_report(allrows,out,cfg)
            csv(pd.DataFrame([dict(categoria=w.category.__name__,mensagem=str(w.message),
                                  arquivo=w.filename,linha=w.lineno) for w in caught]),out/'tabelas/warnings.csv')
            for w in caught: logger.warning('%s: %s',w.category.__name__,w.message)
        manifest['status']='CONCLUIDO_REVISAR_DIAGNOSTICOS'
        if not any(r.get('modelo')!='NULO' and r.get('convergiu') for r in allrows):
            manifest['status']='SEM_MODELO_PREDITIVO_CONVERGENTE'
        logger.info('Concluido. Saidas: %s',out)
    except Exception:
        manifest['status']='ERRO'
        logger.exception('Execucao interrompida; consulte os arquivos ja gravados.')
        raise
    finally:
        if conn: conn.close()
        manifest['segundos']=time.perf_counter()-started
        (out/'manifesto.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
        for handler in [fh,sh]:
            handler.close(); logger.removeHandler(handler)
    return out
