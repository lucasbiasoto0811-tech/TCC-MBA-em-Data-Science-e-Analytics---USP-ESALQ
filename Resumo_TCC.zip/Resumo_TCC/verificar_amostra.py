"""Teste tecnico na amostra de UM semestre. Nao simula validacao temporal."""
from pathlib import Path
import argparse,json,logging,platform,time,warnings
import pandas as pd
import numpy as np
from threadpoolctl import threadpool_limits
from modelagem import load_dims,prepare,eda,load_period,csv
from estimacao import Desenho,fit_count,metrics


def verificar(path,saida):
    root=Path(__file__).parent.resolve()
    cfg=json.loads((root/'config.json').read_text())
    cfg.update(pasta_dados=str(path.parent),pasta_dimensoes=str(root/'dimensoes'),
               arquivos={'202001':path.name},modo_amostra=True)
    for p in ['tabelas','figuras']: (saida/p).mkdir(parents=True,exist_ok=True)
    logger=logging.getLogger('amostra');logger.addHandler(logging.StreamHandler());logger.setLevel(logging.INFO)
    start=time.perf_counter()
    with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=2):
        warnings.simplefilter('always')
        dims=load_dims(cfg,saida)
        conn,sample=prepare(cfg,saida,dims,logger)
        eda(conn,sample,saida)
        df=load_period(conn,'202001');conn.close()
        rows=[]
        for kind in cfg['modelos']:
            design=Desenho(kind).fit(df)
            x=design.transform(df)
            for family in cfg['familias']:
                fit=fit_count(x,df.Y,df.E,design.penalty(.01,.01,.01),family)
                row=dict(modelo=kind,familia=family,n=len(df),convergiu=fit.success,
                         gradiente=fit.gradient,alpha=fit.alpha,alpha_no_limite=fit.alpha_boundary,
                         segundos=fit.seconds,iteracoes=fit.iterations,
                         linhas_J=int(df.SEXO.eq('J').sum()),sinistros_J=float(df.loc[df.SEXO.eq('J'),'Y'].sum()))
                if fit.success:
                    mu=fit.predict(x,df.E)
                    row['mu_J']=float(mu[df.SEXO.eq('J')].sum())
                    row['todos_coeficientes_finitos']=bool(np.isfinite(fit.beta).all())
                rows.append(row)
                print(row,flush=True)
        csv(pd.DataFrame(rows),saida/'AJUSTES_AMOSTRA_REAL_TREINO.csv')
        csv(pd.DataFrame([dict(categoria=w.category.__name__,mensagem=str(w.message)) for w in caught]),saida/'warnings.csv')
    status=dict(python=platform.python_version(),linhas_amostra_original=5000,
                linhas_validas=len(df),somente_ajuste_no_mesmo_semestre=True,
                lambda_fixo_de_verificacao=.01,nenhuma_selecao_de_modelo=True,
                todos_convergiram=bool(all(r['convergiu'] for r in rows)),
                segundos=time.perf_counter()-start,n_warnings=len(caught))
    (saida/'STATUS.json').write_text(json.dumps(status,indent=2))
    print(status)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('amostra');ap.add_argument('saida')
    a=ap.parse_args();verificar(Path(a.amostra).resolve(),Path(a.saida).resolve())
