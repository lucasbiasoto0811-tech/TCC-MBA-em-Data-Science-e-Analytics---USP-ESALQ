# Resultados empíricos GLM × GAM — SUSEP 2020

**Os resultados estão prontos. Não é necessário executar nenhum modelo.**

Extraia o ZIP e abra `resultados/RELATORIO_RESULTADOS.html` no navegador. O relatório inclui tabelas, cinco gráficos e uma proposta de redação para o TCC. As imagens estão incorporadas ao HTML, que também pode ser impresso pelo navegador.

## Conteúdo

- `resultados/RELATORIO_RESULTADOS.html`: análise completa, tabelas e figuras.
- `resultados/TEXTO_PARA_TCC.md`: proposta de texto para resultados e conclusão.
- `resultados/tabelas/`: onze CSVs editáveis, separados por `;`, com vírgula decimal e UTF-8 BOM, compatíveis com Excel em português.
- `resultados/figuras/`: cinco gráficos, cada um em PNG 300 dpi, PDF vetorial e SVG editável.
- `resultados/manifesto_consolidacao.json`: procedência, hashes, versões e verificações.
- `fontes_v03/`: cópia dos arquivos de resultados necessários para reproduzir esta consolidação. A subpasta `auditoria_previa` fornece estatísticas integrais do mesmo recorte para calcular R², sem reutilizar previsões antigas. Não contém a base SUSEP completa, dados individuais adicionais ou modelos serializados.
- `07_consolidar_resultados.py`: script independente de pós-processamento. Não importa bibliotecas de modelagem nem estima parâmetros.

## Como reproduzir

No PowerShell, dentro da pasta extraída, utilizando seu ambiente Python 3.11 com `numpy`, `pandas` e `matplotlib`:

```powershell
python .\07_consolidar_resultados.py
```

O programa lê as fontes incluídas e recria somente tabelas, gráficos e relatório. Foi executado em poucos segundos neste ambiente; o tempo pode variar entre máquinas. Não é necessário usar a base de seis milhões de linhas, nem rodar `05_executar_revisao.py` ou `06_complementar_busca.py`.

Para salvar outra cópia dos resultados:

```powershell
python .\07_consolidar_resultados.py --saida .\resultados_reproduzidos
```

A execução verifica o manifesto original e a integridade das fontes. Não edite `fontes_v03`; faça mudanças de apresentação no script ou em uma cópia das saídas. Os CSVs conservam a precisão original dos resultados; a apresentação arredonda apenas a exibição.

## Leitura das tabelas

| Arquivo | Conteúdo |
|---|---|
| `01_metricas_completas.csv` | Todos os 18 ajustes selecionados, treino e avaliação, métricas, penalidades e custo de ajuste |
| `02_modelos_selecionados.csv` | Especificações e penalizações selecionadas na execução original |
| `03_pares_temporais.csv` | Comparação GLM/GAM na mesma estrutura e família, com diferenças absolutas e relativas e indicação de comparabilidade |
| `04_CV_controlada.csv` | Todos os 40 pares elegíveis com penalizações comuns iguais, sem escolher apenas os pares favoráveis |
| `05_CV_controlada_por_fold.csv` | As três diferenças por fold de cada par, para rastreabilidade; não são repetições independentes |
| `06_elegibilidade_CV.csv` | Todos os candidatos originais e suas condições de convergência |
| `07_calibracao_integral.csv` | O/E e erros por grupos, mantendo todas as observações do recorte |
| `08_complexidade_EDF.csv` | Quantidade de coeficientes e EDF condicionais disponíveis; coeficientes não equivalem a graus de liberdade efetivos |
| `09_reconciliacao.csv` | Reconciliação dos totais com suas partições de diagnóstico |
| `10_metricas_solicitadas.csv` | MAE, MSE, RMSE e R² convencional das contagens; status do MAPE e WAPE complementar |
| `11_referencia_populacao_R2.csv` | n, soma de Y, soma de Y² e soma dos quadrados em torno da média, por semestre |

Diferença percentual de perda = `100 × (GAM / GLM − 1)`. Valor positivo favorece GLM; negativo favorece GAM. Essa regra não se aplica diretamente a O/E, cujo alvo é 1.

## Métricas acrescentadas na versão 1.1

- **MAE e RMSE:** já existiam, com os nomes `MAE_contagem` e `RMSE_contagem`. Continuam preservados.
- **MSE:** calculado como `RMSE_contagem²`, conferido com a soma integral dos erros quadráticos dividida pelo número de células.
- **R² convencional:** `1 − SSE/SST`, usando `SSE = n × MSE` e `SST = soma_y2 − soma_y²/n`. É calculado sobre todas as células de cada semestre, sem ponderação adicional. Não é R² ajustado, pseudo-R² ou quadrado da correlação.
- **MAPE:** a fórmula usual é indefinida na presença de contagens observadas iguais a zero. O campo numérico fica vazio/NaN e `MAPE_situacao` informa o motivo. Não se removem zeros nem se divide por epsilon para criar um valor finito.
- **WAPE complementar:** `100 × soma dos erros absolutos / soma dos sinistros`, disponível porque o total de sinistros é positivo. Pode exceder 100%; não se confunde com MAPE ou percentual de registros errados.

R² maior é melhor, enquanto MAE, MSE e RMSE menores são melhores. R² pode ser negativo. Sua referência é a média observada de Y no próprio período de avaliação; essa referência serve apenas para calcular a métrica, não recalibra o modelo. O modelo nulo com offset varia com a exposição, por isso seu R² convencional pode ser diferente de zero.

MSE e RMSE são transformações uma da outra; com a mesma resposta e o mesmo conjunto de células, R² também produz a mesma ordenação que o MSE. Portanto, as três não constituem evidências independentes. São indicadores complementares à NLL, deviance e calibração, e são sensíveis às células extremas.

## Conclusão e limite inferencial

O material sustenta uma **conclusão empírica limitada às especificações e ao desenho executados**: não foi demonstrada vantagem consistente dos GAMs avaliados, e algumas comparações apresentaram diferenças numericamente muito pequenas.

Não se executou teste formal de diferença ou equivalência. Portanto, o pacote não declara `p > 0,05`, “H0 aceita”, “ausência de diferença estatisticamente significativa” ou “equivalência estatística”. Não rejeitar diferença, caso houvesse um teste apropriado, também não seria suficiente para demonstrar equivalência.

Os GAMs com grupos selecionados tiveram perdas temporais maiores, mas a cobertura desigual da busca impede atribuir essa diferença exclusivamente à classe de modelo. Os pares internos sob penalizações comuns iguais são apresentados separadamente, com seu alcance explícito. “Com grupos” se refere aos efeitos penalizados/MAP condicionais implementados.

O semestre 202002 já foi consultado e é uma avaliação temporal exploratória. A consolidação não elimina essa característica do desenho.

Preserve também o projeto original e seus dados: este pacote reproduz **a apresentação e as comparações dos resultados salvos**, não os ajustes originais a partir da base bruta.
