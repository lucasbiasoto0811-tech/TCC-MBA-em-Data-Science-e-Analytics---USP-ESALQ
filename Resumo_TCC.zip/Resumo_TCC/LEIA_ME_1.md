# TCC AUTOSEG — primeira comparação de modelos

J é mantido no principal com regularização. A análise de sensibilidade sem J
também é executada. Tudo roda em Python, sem R.

## Como executar no Windows, VSCode ou Spyder

1. Extraia este pacote em uma pasta própria. As dez dimensões estão incluídas.
2. Coloque os dois CSVs completos de 2020 em uma pasta de dados.
3. Abra `config.json` e altere somente `pasta_dados`, por exemplo:

       "pasta_dados": "C:/Users/Lucas/Documents/SUSEP/dados"

   Use barras `/` no JSON. Os nomes esperados são
   `arq_casco_comp_202001.csv` e `arq_casco_comp_202002.csv`.
   Os demais caminhos são relativos à pasta de config.json.
4. No ambiente Python 3.11 usado pela sua IDE, instale:

       python -m pip install -r requirements.txt

   Se houver mais de um Python, confira `import sys; print(sys.executable)`
   no console da IDE e use esse interpretador para instalar as dependências.
5. Execute `01_executar.py` na IDE, ou no terminal:

       python 01_executar.py

   Alternativa: abra `02_Executar_e_revisar.ipynb` na pasta extraída.
6. A pasta `resultados/execucao_...` conterá tabelas CSV, gráficos PNG/PDF,
   base tratada SQLite, modelos, configurações efetivas, hashes e log.

Leia `METODOLOGIA.md` antes de interpretar coeficientes ou comparar modelos.

## O que será executado

- Importação dos dois semestres e de todas as dimensões.
- Validação da chave, das contagens, da exposição e do ENVIO correto.
- Exclusão de exposição não positiva com rastreabilidade.
- Preservação de NULL, de códigos não informados e de códigos sem dimensão.
- EDA com totais exatos e histogramas/quantis amostrais identificados.
- Seleção de penalidades somente dentro do primeiro semestre.
- Ajuste integral de Poisson e NB2, nas versões nula, GLM, GAM e extensões
  de grupos com estimação MAP condicional; repetição sem J como sensibilidade.
- Avaliação temporal no segundo semestre, calibração, resíduos e curvas.

O ajuste usa os seis milhões de registros retidos, divididos por semestre;
a busca interna de penalidades usa uma subamostra para reduzir custo.
O processamento pode demorar; o log informa o modelo em andamento.
Não há estimativa de duração nem garantia medida de pico de RAM na base completa.
SQLite e saídas precisam de espaço livre em disco. Previsões por célula ficam
desabilitadas por padrão; ative `salvar_predicoes_celulas` se forem necessárias.

## Arquivos para me devolver após a execução

1. `tabelas/comparacao_consolidada.csv`.
2. `tabelas/recorte.csv`.
3. `tabelas/selecionados_*.csv` e `tabelas/selecao_*.csv` dos dois cenários.
4. `tabelas/warnings.csv` e `execucao.log`.
5. `manifesto.json`.

Não precisa enviar novamente os CSVs de 300 MB. Se ocorrer erro, envie o log
mesmo que a execução não tenha terminado. Ele estará na pasta desta execução.

## Cuidados com a interpretação

Esta implementação compara predições condicionais. A extensão por grupos é
MAP com penalidades selecionadas por validação; não é um ajuste marginal por
REML. Não entrega ICC ou variâncias hierárquicas populacionais. Intervalos,
quando calculados, são locais e condicionais; não são inferência robusta final.
AIC/BIC aproximados não decidem o vencedor. Veja todas as limitações no protocolo.

Não há testes bootstrap com reajuste, ZIP/hurdle, validação de grupos inteiramente
novos ou inferência marginal implementados nesta versão. Essas extensões dependem
dos diagnósticos e da justificativa, não serão substituídas por números artificiais.

Os arquivos em `verificacao/` documentam testes técnicos, inclusive testes com
dados sintéticos. Nenhum resultado sintético deve ser usado nas tabelas do TCC.
A amostra real disponível pertence a um único semestre: ela permite verificar
a estimação e a EDA, mas não a comparação temporal nos arquivos completos.

## Parâmetros e reprodutibilidade

Todas as escolhas editáveis estão em config.json. Aumentar limites de amostra,
nós ou grade de penalidades altera o protocolo e o custo. Não use os resultados
do segundo semestre para mudar esses parâmetros e depois chamá-lo novamente
de teste independente. Uma alteração motivada pelo teste exige nova validação.

`verificar_calculos.py` verifica as fórmulas do estimador com implementações
independentes e dados sintéticos. Rode com `python verificar_calculos.py` se quiser
reproduzir essa verificação no seu ambiente. A conclusão sem erro do pipeline
não substitui a avaliação estatística dos outputs.
