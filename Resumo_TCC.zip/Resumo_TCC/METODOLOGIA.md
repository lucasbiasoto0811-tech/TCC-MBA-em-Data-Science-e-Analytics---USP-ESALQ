# Protocolo de modelagem AUTOSEG — versão 0.2.0

Decisões incorporadas em 25/09/2026. Este pacote é uma primeira comparação
executável, não uma conclusão do TCC nem um modelo aprovado para tarifação.
Todos os componentes são Python; nenhuma instalação de R é necessária.

## 1. População e unidade de análise

Cada observação é uma célula agregada definida por COD_TARIF, REGIAO,
COD_MODELO, ANO_MODELO, SEXO e IDADE em um semestre. A chave não identifica
um veículo individual, apólice ou pessoa. SEXO + IDADE não identifica condutor.
As dimensões auto2_vei e auto2_grupo vinculam modelos de veículos a grupos.
Códigos FIPE são mantidos como texto, inclusive zeros iniciais e hífen.

A resposta Y=FREQ_SIN2 é **contagem** de sinistros de colisão parcial, não
uma taxa pronta. E=EXPOSICAO1 é a exposição documentada pelo AUTOSEG. Usa-se
log(E) como offset desde o modelo nulo; não se constrói um modelo sem
exposição para depois adicioná-la como se fosse uma covariável comum.
A taxa descritiva de um grupo é sum(Y)/sum(E), nunca a média simples de Y/E.

Mantêm-se apenas E>0 por decisão do pesquisador. Y ou E ausentes, não finitos
ou Y negativo/não inteiro interrompem o processamento, com relatório de erro.
E<=0 é excluído e contabilizado; E negativo é identificado separadamente.
Não se realocam os sinistros das células excluídas para outras células.

Os perfis integrais já auditados implicam 6.089.446 linhas mantidas,
661.623 sinistros mantidos e 124.691 sinistros excluídos (15,86% do original).
Estes totais são referência da auditoria anterior; o código recalcula seus
próprios totais e não os impõe aos dados. Grandes amostras não removem viés
por incompatibilidade de codificação entre exposição e sinistros.

EXPOSICAO1 refere-se à base CASCO publicada. Não há nesta documentação
uma exposição específica adicional para a elegibilidade à colisão parcial.
A interpretação permanece frequência registrada por exposição CASCO do recorte,
não frequência individual entre contratos comprovadamente elegíveis à cobertura.

## 2. Missing e variáveis

- Ausência literal nas categorias: `__NULL__`, mantida como nível.
- SEXO=0 e IDADE=0: códigos documentados de informação ausente, preservados.
- Código não encontrado na dimensão: preservado, com status SEM_CORRESPONDENCIA.
  Não confundir com NULL. Modelo informado sem dimensão não perde seu código.
- COD_GRUPO é obtido apenas da dimensão. Sem modelo: __NULL_MODELO__;
  modelo sem correspondência: __SEM_DIMENSAO__. Estes não são grupos conhecidos.
- IDADE é faixa etária categórica. Não há spline de idade individual inventada.
- ANO_MODELO com quatro dígitos é usado como ano contínuo; valores especiais
  permanecem em ANO_STATUS. A ausência tem efeito categórico próprio e efeito
  contínuo zero. Centro/nós do ano são aprendidos no conjunto de ajuste.
- Um ano de quatro dígitos não é automaticamente um ano válido do domínio:
  consultar o perfil de anos antes de interpretar curvas. Não há winsorização
  nem corte arbitrário para fazer um ajuste convergir. Modelo 2021 pode constar
  em 2020; não é transformado em idade negativa de veículo.
- PREMIO1 é soma ponderada pela exposição, segundo o documento recebido;
  PREMIO_MEDIO=PREMIO1/E aparece somente na EDA. IS_MEDIA e INDENIZ2 também
  são descritivas nesta versão. INDENIZ2 e contagens de outras causas não
  entram como preditores. Prêmios contemporâneos e IS média agregada não têm
  disponibilidade na entrada do risco comprovada; não entram no modelo
  preditivo principal até esclarecer esse ponto.
- Não há imputação da resposta, da exposição ou de sinistros ausentes como zero.

O status da ausência pode refletir seleção, registro ou processamento posterior
ao evento. Mesmo uma associação estável fora da amostra não prova causalidade
nem disponibilidade dessa informação na subscrição individual.

## 3. J e escopo da regularização

J=Jurídica permanece no modelo principal por decisão explícita do pesquisador.
Os perfis enviados têm exposição relevante e zero FREQ_SIN2 em J nos dois
semestres. Não se conclui risco real nulo; não se declara zero estrutural.
A sensibilidade exclui apenas J, preservando NULL e códigos de informação ausente.

Todos os coeficientes categóricos são penalizados, inclusive o de J; somente
o intercepto não recebe ridge. Isso permite estimativas finitas apesar da
separação causada por um nível sem eventos. Penalizar apenas os splines de um
GAM não resolveria um coeficiente categórico não penalizado que diverge.
Regularização resolve a estimação numérica, não a origem da anomalia de registro.
Não se adicionam sinistros fictícios nem pseudocontagens a J.

## 4. Modelos

Para célula i:

    Y_i | x_i, u, v ~ Poisson(mu_i) ou NB2(mu_i, alpha)
    log(mu_i) = log(E_i) + eta_i
    Var_Poisson(Y_i)=mu_i
    Var_NB2(Y_i)=mu_i+alpha*mu_i²

Alpha da NB2 é estimado com os coeficientes, por verossimilhança penalizada.
Não é fixado em 1. Alpha tem limites numéricos exp(-12) a exp(8), cuja ativação
é sinalizada. Fronteira inferior pode indicar aproximação a Poisson; superior
pode indicar inadequação/instabilidade, exigindo revisão.

NULO: intercepto e offset, para cada família.
GLM: COD_TARIF + SEXO + IDADE + COD_GRUPO + REGIAO + ANO_STATUS + ano linear.
GAM: mesmas categorias; ano linear substituído por B-spline cúbica penalizada.
Apenas uma relação contínua, ano, é suavizada nesta primeira especificação.

A função minimizada é:

    -log L(beta,alpha)/n + beta' P beta / 2.

Há ridge lambda_fixo nos coeficientes e, nos splines, penalidade adicional de
segundas diferenças lambda_smooth ||D2 theta||²/2. Número de nós é configurável;
o padrão é seis, uniformes no suporte do ajuste. Extrapolação spline constante,
explicitamente reportada como fora de suporte. No GLM, extrapolação é linear.
Com menos de quatro anos distintos, GAM usa termo linear e isso aparece no
objeto/fórmula: não se inventa uma curva a partir de suporte insuficiente.

A implementação usa NumPy/SciPy, CSR e L-BFGS-B. scikit-learn fornece a
codificação e as bases de spline. As fórmulas da NB2 foram verificadas contra
scipy.stats e os gradientes contra diferenças finitas. O Poisson penalizado
foi comparado independentemente com PoissonRegressor usando a equivalência
correta de offset e ponderação (arquivo verificar_calculos.py).

## 5. O que significa a extensão por grupos

GLM_GRUPOS/GAM_GRUPOS substituem o efeito de REGIAO por u_regiao e acrescentam
v_modelo, mantendo COD_GRUPO para diferenças entre grupos de veículos:

    eta_i = beta0 + x_i'beta + f(ano_i) + u_regiao[i] + v_modelo[i].

Região e modelo são cruzados; modelo está vinculado ao grupo pela dimensão,
mas não representa veículo individual. Não existe nível de condutor identificado.
Os códigos de modelo sem dimensão mantêm seu efeito específico, sem uma
alegação de aninhamento em grupo veicular conhecido.

Penalidades ridge dos blocos u/v equivalem a modos posteriores gaussianos
condicionais, com precisão n*lambda_grupos. Usa-se um lambda comum aos dois
blocos nesta versão, para limitar a busca; não se supõem variâncias separadas
estimadas por REML. É uma hipótese restritiva, registrada, a avaliar depois.

**Não são GLMM/GAMM de verossimilhança marginal integrada.** Não se estimam
componentes populacionais de variância nem ICC. A variância empírica dos
coeficientes encolhidos não substitui esses componentes. O papel desta extensão
é comparar predições condicionais com compartilhamento de informação entre
células. A defesa de um GAM multinível marginal no TCC exigiria etapa adicional
(Laplace/integração ou Bayes) e verificação de viabilidade na máquina disponível.

Para níveis não observados no treino, a contribuição estimada é zero e a
exposição afetada é reportada. Nos efeitos aleatórios isso é previsão plug-in
condicionada a u/v=0, **não** média marginal lognormal integrada. O uso em níveis
novos exige avaliação própria. Não alegar equivalência integral ao mgcv.

## 6. Validação sem usar o teste para escolher penalidades

Mapeamento oficial dos links SUSEP:
202001, primeiro semestre de 2020, ENVIO=2020B;
202002, segundo semestre de 2020, ENVIO=2021A.
O código anterior de auditoria que presumiu outra convenção A/B produziu um
alerta indevido. Aqui o mapeamento é explícito e validado, sem alterar a fonte.

Treino/desenvolvimento: primeiro semestre. Teste temporal: segundo semestre.
Dentro do primeiro, hash das seis variáveis-chave define cinco partições;
uma é validação interna e quatro formam ajuste interno. Isto é **um holdout
interno**, não validação cruzada de cinco rodadas. A chave inteira fica numa
única partição. Modelos/regiões podem aparecer em ambas, coerente com prever
novas células de grupos conhecidos. Não testa generalização a modelos de
veículo inteiramente novos; não há IDs individuais para controlar repetição
da mesma apólice ou pessoa. Essa dependência residual é uma limitação.

Para custo computacional, a busca de lambdas usa amostras uniformes de até
100 mil células de ajuste e 50 mil de validação interna, iguais entre candidatos
dentro do cenário. A amostragem não remove células do ajuste final: cada modelo
selecionado é reajustado em **todo o primeiro semestre** do seu cenário.
Seleciona-se por log-score de contagem na validação, registrando também deviance.
O critério por célula e a deviance por exposição respondem a prioridades distintas.
A qualidade da grade/subamostragem deve ser verificada; ótimo na borda não
significa ótimo global. Estabilidade a outra semente/tamanho é análise futura.

Não se aprende mediana, spline, categorias, lambdas ou dispersão no segundo
semestre. Cortes dos decis são aprendidos no treino, ponderados pela exposição;
empates ficam juntos e podem resultar em menos de dez grupos. Não se recalibra
o intercepto com o teste. A auditoria anterior já examinou suas marginais,
portanto este teste temporal não foi totalmente cego. Dois semestres não permitem
uma conclusão forte sobre estabilidade plurianual ou causalidade de mudanças
em 2020. Uma extensão com anos adicionais será necessária para generalização.

Os cenários principal e sem J são ajustados e avaliados separadamente. Seus
AICs, likelihoods totais e deviances totais não são comparáveis diretamente,
pois se referem a populações diferentes. Dentro de cada cenário, GLM e GAM
usam as mesmas linhas/famílias/regras de validação.

## 7. Diagnósticos e interpretação

Saídas completas por modelo: log-likelihood condicional, deviance da família,
deviance Poisson comum, Pearson, RMSE/MAE de contagens, erros de taxa ponderados
por exposição, O/E e taxas agregadas. MAPE não é calculado porque Y tem zeros.
Razão variância/média marginal é descritiva; não testa Poisson condicional.
Excesso de zeros é avaliado relativamente à distribuição ajustada, não ao total
marginal de zeros. QQ usa resíduos quantílicos aleatorizados, não exige
normalidade de resíduos de Pearson. Não há teste formal de adequação com
refit bootstrap implementado nesta versão; as evidências são diagnósticas.

As tabelas de calibração usam todos os registros da partição. Gráficos de
resíduos e influência usam uma amostra uniforme reprodutível de até 15 mil
células. Histogramas e quantis da EDA usam até 25 mil células por semestre;
as tabelas por categoria e totais são exatas. Transformações log nos gráficos
não modificam os dados de modelagem. Não se eliminam outliers por resíduos.

Quando a matriz tem até 900 colunas, calcula-se:

    H = X' W X, W=mu/(1+alpha*mu)
    V = (H+nP)^(-1)
    EDF = tr(V H).

V é aproximação local posterior de beta, condicionada a alpha e lambdas.
Bandas de curvas são pontuais, não simultâneas. Não incluem incerteza de seleção,
incerteza de alpha nem correção de dependência residual. Não são intervalos
frequentistas robustos; não se fabricam p-valores de significância convencional.
Os coeficientes de uma base spline isolados não têm interpretação de risco;
usam-se curvas relativas ao ano central do treino.

Leverage e Cook aproximado referem-se ao ajuste local penalizado no treino,
com df efetivo. Não são diagnósticos exatos por exclusão e reajuste da observação.
AIC/BIC rotulados condicionais/aproximados usam EDF (+1 para alpha NB2); não
corrigem a escolha dos lambdas e não são critérios marginais GLMM. Não são o
critério principal de seleção. Para matrizes maiores, EDF/intervalos/influência
ficam indisponíveis com motivo registrado, preservando o orçamento de memória;
não se substitui EDF pelo número bruto de coeficientes.

Modelos sem convergência satisfatória ficam fora da comparação e constam nos
logs/status. Nenhuma falha é ocultada com um modelo substituto. Alpha na fronteira
também é reportado. Os warnings são gravados. Há arquivos parciais se ocorrer erro.

Quasi-Poisson não define likelihood completa e não participa de AIC/log-score.
ZIP/hurdle não são acionados automaticamente: requerem hipótese de processo e
verificação de zeros residuais após covariáveis/heterogeneidade. Subdispersão
persistente demandaria outra família (não implementada). Nenhuma distribuição
é declarada adequada antecipadamente.

## 8. Execução, reprodutibilidade e limites

Python 3.11, versões fixadas, seed, hash SHA256 de entradas e scripts, parâmetros,
logs e status ficam registrados. Leitura dos CSVs é por blocos; a base tratada
é SQLite e as matrizes são esparsas. O ajuste final carrega colunas selecionadas
do treino/teste em RAM. Não foi medido pico de RAM nem tempo nos seis milhões
de registros: disponibilidade de 16 GB é um alvo de projeto, não garantia.
Há processamento sequencial e limite de duas threads para conter recursos.
Se a cardinalidade real for muito maior, será necessário adaptar o estimador;
não substituir silenciosamente o ajuste integral por uma amostra.

Não há instalação automática, acesso de rede ou execução de R pelo pipeline.
Arquivos originais são apenas lidos. Cada execução tem pasta própria. Predições
individuais podem ser volumosas e são opcionais; calibração agregada sempre sai.

Etapas do pedido inicial mapeadas: configuração/importação/qualidade/preparo/EDA
em modelagem.py; dispersão e métricas em estimacao.py; GLM/GAM/grupos em ambos;
validação, comparação, diagnósticos, tabelas e figuras em modelagem.py. O notebook
organiza execução, leitura e revisão. O modelo final científico depende da
revisão dos resultados integrais, não apenas da conclusão sem erro do script.

## Referências verificáveis

SUSEP. Definição de conceitos e variáveis do Sistema Autoseg. PDF recebido,
incluído no pacote. Página de distribuição e semestres:
https://www2.susep.gov.br/menuestatistica/autoseg/principal.aspx

scikit-learn. Poisson regression and non-normal loss; exemplo de frequência
com exposição. Utilizado como verificação independente, não como fonte de dados:
https://scikit-learn.org/1.8/auto_examples/linear_model/plot_poisson_regression_non_normal_loss.html

scikit-learn. SplineTransformer (documentação 1.8):
https://scikit-learn.org/1.8/modules/generated/sklearn.preprocessing.SplineTransformer.html

statsmodels. NegativeBinomial: modelo de contagem com exposure/offset e NB2:
https://www.statsmodels.org/stable/generated/statsmodels.discrete.discrete_model.NegativeBinomial.html

Wood, S. N.; Pya, N.; Säfken, B. Smoothing parameter and model selection for
general smooth models. Preprint de 2015:
https://arxiv.org/abs/1511.03864
A referência discute estimação marginal de suavização. O presente código usa
seleção preditiva de penalidades, e não implementa esse algoritmo de Wood et al.

mgcv, documentação oficial. Random effects in GAMs (referência conceitual,
sem dependência do R no pacote):
https://stat.ethz.ch/R-manual/R-devel/library/mgcv/html/random.effects.html
