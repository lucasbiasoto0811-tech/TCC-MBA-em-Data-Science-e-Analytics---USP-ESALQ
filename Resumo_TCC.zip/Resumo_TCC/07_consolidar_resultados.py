"""Consolidacao descritiva de resultados existentes. NENHUM modelo e ajustado.

Python 3.11+. Dependencias: numpy, pandas, matplotlib.
Execute: python 07_consolidar_resultados.py
As fontes necessarias acompanham o pacote; nao precisa do SQLite ou da base.
"""
from pathlib import Path
import argparse
import base64
import hashlib
import html
import importlib.metadata
import io
import json
import logging
import platform
import time

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

VERSION='1.1-consolidacao-com-R2-MSE'
EXPECTED='ac4450c868a59a8f237fc41b2b991505d5bd3a06045eb342cd40e31e8ec9f64e'
STRUCTURES=['','_INTER','_GRUPOS','_INTER_GRUPOS']
LABELS={'':'Aditivo','_INTER':'Com interação','_GRUPOS':'Com grupos','_INTER_GRUPOS':'Interação + grupos'}
BLUE='#24547a'
ORANGE='#cf6b35'
COLORS={.01:'#24776d',1.:'#bf6b2e',10000.:'#74598d'}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return pd.read_csv(path,sep=';',decimal=',',encoding='utf-8-sig')
def save(df,path):df.to_csv(path,sep=';',decimal=',',index=False,encoding='utf-8-sig')
def js(data,path):path.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def bools(series):
    result=series.astype(str).str.lower().map({'true':True,'false':False,'1':True,'0':False})
    if result.isna().any():raise ValueError('Indicador booleano invalido.')
    return result.astype(bool)
def number(x,digits=6):
    if pd.isna(x):return 'Não disponível'
    return f'{float(x):,.{digits}f}'.replace(',','@').replace('.',',').replace('@','.')


def extended_metrics(metrics,source):
    """R2 convencional das contagens integrais, nao pseudo-R2 ou R2 amostral.

    A auditoria anterior fornece estatisticas da MESMA populacao. Somente
    n, soma(Y), soma(Y^2), exposicao e zeros sao reutilizados, nunca previsoes
    dos modelos anteriores. A soma de quadrados residual vem dos modelos 0.3.
    """
    previous=source/'auditoria_previa'
    audit_manifest=json.loads((previous/'manifesto_auditoria.json').read_text(encoding='utf-8-sig'))
    current_manifest=json.loads((source/'manifesto.json').read_text(encoding='utf-8-sig'))
    if audit_manifest['manifesto_origem_sha256']!=current_manifest['manifesto_origem_sha256']:
        raise ValueError('As estatisticas anteriores nao pertencem a mesma origem.')
    if audit_manifest['linhas_excluidas_nesta_auditoria']!=0:
        raise ValueError('Auditoria anterior mudou o recorte.')
    audit=read(previous/'resumo_integral.csv')
    dispersion=read(previous/'dispersao_marginal.csv').set_index('PERIODO')
    result=metrics.copy();population=[]
    result['MSE_contagem']=result.RMSE_contagem**2
    result['R2_contagem']=np.nan
    result['MAPE_percentual']=np.nan
    result['MAPE_situacao']=''
    result['WAPE_percentual']=100*result.MAE_contagem*result['n']/result.sinistros
    result['percentual_celulas_zero']=100*result.zeros_observados/result['n']
    for period,partition in [(202001,'treino_202001'),(202002,'exploratorio_202002')]:
        p=audit[audit.PERIODO.eq(period)]
        cols=['linhas','exposicao','observados','soma_y2','zeros_obs']
        if len(p)==0 or any(p[c].nunique()!=1 for c in cols):
            raise ValueError('Estatisticas da populacao ausentes ou divergentes.')
        r=p.iloc[0];d=dispersion.loc[period]
        for col,other in [('linhas','n'),('exposicao','exposicao'),('observados','sinistros'),('soma_y2','soma_y2'),('zeros_obs','zeros')]:
            if not np.isclose(r[col],d[other],rtol=1e-10,atol=1e-8):
                raise ValueError('Auditoria e dispersao nao reconciliam: '+col)
        mask=result.particao.eq(partition);q=result.loc[mask]
        for col,sourcecol in [('n','linhas'),('sinistros','observados'),('exposicao','exposicao'),('zeros_observados','zeros_obs')]:
            if not np.allclose(q[col],r[sourcecol],rtol=1e-10,atol=1e-8):
                raise ValueError('Recorte 0.3 difere da populacao auditada: '+col)
        sst=float(r.soma_y2-r.observados**2/r.linhas)
        if sst<=0:raise ValueError('R2 indefinido para resposta constante ou estatisticas invalidas.')
        result.loc[mask,'R2_contagem']=1-result.loc[mask,'MSE_contagem']*q['n']/sst
        result.loc[mask,'MAPE_situacao']='Indefinido na formula usual: ha contagens observadas iguais a zero.'
        if r.zeros_obs<=0:raise ValueError('Este caso exige calcular o MAPE a partir das previsoes individuais.')
        population.append(dict(periodo=period,particao=partition,n=int(r.linhas),soma_y=float(r.observados),
             soma_y2=float(r.soma_y2),zeros=int(r.zeros_obs),exposicao=float(r.exposicao),
             media_y=float(r.observados/r.linhas),SST_contagem=sst,
             referencia_R2='Media da contagem no proprio periodo avaliado; nenhuma recalibracao do modelo.'))
    return result,pd.DataFrame(population)


def figsave(fig,out,name,caption,top=.94):
    fig.text(.02,.015,caption,ha='left',va='bottom',fontsize=9,color='#444444')
    fig.tight_layout(rect=(0,.065,1,top))
    for ext in ['png','pdf','svg']:
        buffer=io.BytesIO()
        fig.savefig(buffer,format=ext,dpi=300,bbox_inches='tight',facecolor='white')
        destination=out/'figuras'/f'{name}.{ext}'
        temporary=destination.with_name(destination.name+'.tmp')
        temporary.write_bytes(buffer.getvalue())
        temporary.replace(destination)
    plt.close(fig)


def paired_selected(metrics):
    rows=[]
    for family in ['poisson','nb2']:
        q=metrics[metrics.familia.eq(family)&metrics.particao.eq('exploratorio_202002')].set_index('modelo')
        for suffix in STRUCTURES:
            a,b=q.loc['GLM'+suffix],q.loc['GAM'+suffix]
            assert a['n']==b['n'] and a.sinistros==b.sinistros and np.isclose(a.exposicao,b.exposicao)
            matched=all(np.isclose(a[k],b[k],rtol=1e-12,atol=0) for k in ['lambda_fixo','lambda_grupos'])
            row=dict(estrutura=LABELS[suffix],familia=family,GLM='GLM'+suffix,GAM='GAM'+suffix,
                     penalidades_comuns_iguais=matched,
                     interpretacao='Comparacao descritiva pareada dos ajustes selecionados' if matched else
                     'Busca desigual das penalidades comuns: nao isola a contribuicao da curvatura')
            for c in ['nll_por_celula','poisson_deviance_por_exposicao','RMSE_contagem','MAE_contagem','OE']:
                row[c+'_GLM']=float(a[c]);row[c+'_GAM']=float(b[c])
                row[c+'_dif_absoluta']=float(b[c]-a[c])
                if c!='OE':row[c+'_dif_percentual']=float(100*(b[c]/a[c]-1))
            row['erro_abs_OE_GLM']=abs(a.OE-1);row['erro_abs_OE_GAM']=abs(b.OE-1)
            rows.append(row)
    return pd.DataFrame(rows)


def controlled_cv(cv):
    cv=cv.copy()
    cv['convergiu']=bools(cv.convergiu);cv['alpha_no_limite']=bools(cv.alpha_no_limite)
    cv['fold_elegivel']=cv.convergiu & ~cv.alpha_no_limite & np.isfinite(cv.nll_total)
    keys=['modelo','familia','fixed','smooth','groups']
    candidates=[]
    for key,g in cv.groupby(keys,dropna=False):
        ok=len(g)==3 and g.fold.nunique()==3 and bool(g.fold_elegivel.all())
        candidates.append(dict(zip(keys,key))|dict(folds=len(g),folds_elegiveis=int(g.fold_elegivel.sum()),
            elegivel=ok,nll_ponderada=g.nll_total.sum()/g.n_validacao.sum() if ok else np.nan,
            segundos=float(g.segundos.sum())))
    candidates=pd.DataFrame(candidates)
    summaries,folds=[],[]
    good=candidates[candidates.elegivel].copy()
    for suffix in STRUCTURES:
        a=good[good.modelo.eq('GLM'+suffix)]
        b=good[good.modelo.eq('GAM'+suffix)]
        matches=a.merge(b,on=['familia','fixed','groups'],suffixes=('_GLM','_GAM'),validate='one_to_many')
        for r in matches.to_dict('records'):
            def select(model,smooth):
                return cv[cv.modelo.eq(model)&cv.familia.eq(r['familia'])&cv.fixed.eq(r['fixed'])
                          &cv.groups.eq(r['groups'])&cv.smooth.eq(smooth)]
            gf=select('GLM'+suffix,r['smooth_GLM']).merge(select('GAM'+suffix,r['smooth_GAM']),
                on='fold',suffixes=('_GLM','_GAM'),validate='one_to_one')
            assert len(gf)==3 and (gf.n_validacao_GLM==gf.n_validacao_GAM).all()
            assert (gf.n_treino_GLM==gf.n_treino_GAM).all()
            identifier=f'C{len(summaries)+1:02d}'
            base=dict(comparacao=identifier,estrutura=LABELS[suffix],familia=r['familia'],
                      lambda_fixo=r['fixed'],lambda_grupos=r['groups'],lambda_curvatura=r['smooth_GAM'])
            for f in gf.to_dict('records'):
                x=f['nll_total_GLM']/f['n_validacao_GLM'];y=f['nll_total_GAM']/f['n_validacao_GAM']
                folds.append(dict(base,fold=int(f['fold']),n_validacao=int(f['n_validacao_GLM']),
                                  nll_GLM=x,nll_GAM=y,dif_absoluta=y-x,dif_percentual=100*(y/x-1)))
            x=r['nll_ponderada_GLM'];y=r['nll_ponderada_GAM']
            local=folds[-3:]
            summaries.append(dict(base,nll_GLM=x,nll_GAM=y,dif_absoluta=y-x,dif_percentual=100*(y/x-1),
                menor_diferenca_folds=min(x['dif_percentual'] for x in local),
                maior_diferenca_folds=max(x['dif_percentual'] for x in local),
                escopo='CV interna reutilizada; comparacoes dependentes; sem teste de significancia'))
    return candidates,pd.DataFrame(summaries),pd.DataFrame(folds)


def diagnostics(source,metrics):
    all_cal,checks,edf=[],[],[]
    columns=['linhas','exposicao','observados','esperados','erro_quadratico','pearson2']
    for r in metrics.to_dict('records'):
        path=source/'tabelas'/f"diagnosticos_integrais_{r['modelo']}_{r['familia']}_{r['particao']}.csv"
        t=read(path);total=t[t.variavel.eq('TOTAL')][columns].iloc[0]
        assert total.linhas==r['n'] and total.observados==r['sinistros']
        assert np.isclose(total.esperados,r['previstos'],rtol=1e-10)
        for variable,g in t.groupby('variavel'):
            ok=bool(np.allclose(g[columns].sum(),total,rtol=1e-8,atol=1e-8))
            checks.append(dict(modelo=r['modelo'],familia=r['familia'],particao=r['particao'],
                               variavel=variable,reconciliado=ok))
            if not ok:raise ValueError('Diagnosticos nao reconciliados: '+path.name)
        t['modelo']=r['modelo'];t['familia']=r['familia'];t['particao']=r['particao'];all_cal.append(t)
        if r['particao']!='treino_202001':continue
        path=source/'tabelas'/f"edf_blocos_{r['modelo']}_{r['familia']}.csv"
        curve=np.nan
        if path.exists():
            g=read(path);s=g.loc[g.bloco.eq('curvatura'),'edf_condicional']
            if len(s):curve=float(s.iloc[0])
        edf.append(dict(modelo=r['modelo'],familia=r['familia'],coeficientes=r['n_coeficientes'],
                        edf_total_condicional=r['edf_condicional'],edf_curvatura_condicional=curve,
                        interpretacao='EDF local condicional; nao teste de nao linearidade' if np.isfinite(curve) else
                        'Sem curvatura ou covariancia nao calculada; ausencia nao significa EDF zero'))
    return pd.concat(all_cal,ignore_index=True),pd.DataFrame(checks),pd.DataFrame(edf)


def make_figures(source,metrics,pairs,controlled,cal,out):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                         'axes.spines.right':False,'axes.titleweight':'semibold','svg.fonttype':'none'})
    q=metrics[metrics.familia.eq('nb2')&metrics.particao.eq('exploratorio_202002')].set_index('modelo')
    fig,axes=plt.subplots(1,2,figsize=(12,5.4))
    y=np.arange(4)
    for ax,col,title in zip(axes,['nll_por_celula','OE'],['Perda logarítmica por célula (menor é melhor)','Observado / esperado (referência = 1)']):
        for prefix,color,offset in [('GLM',BLUE,-.17),('GAM',ORANGE,.17)]:
            vals=[q.loc[prefix+s,col] for s in STRUCTURES]
            bars=ax.barh(y+offset,vals,height=.30,color=color,label=prefix)
            for j,bar in enumerate(bars):
                if 'GRUPOS' in STRUCTURES[j]:bar.set_hatch('//');bar.set_edgecolor('#ffffff')
        ax.set_yticks(y,[LABELS[s]+(' †' if 'GRUPOS' in s else '') for s in STRUCTURES])
        ax.invert_yaxis();ax.set_title(title,fontsize=11);ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x,p:number(x,2)))
    axes[1].axvline(1,color='#444444',ls='--',lw=1)
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.53,.93),ncol=2,frameon=False)
    fig.suptitle('Modelos NB2 selecionados · avaliação temporal exploratória em 202002',fontsize=13)
    figsave(fig,out,'01_avaliacao_temporal_NB2',
            '† Pares com grupos: penalidades comuns diferentes e cobertura desigual da busca.\n'
            'Resultados descritivos dos ajustes selecionados; as barras não representam incerteza estatística.',top=.87)

    fig,axes=plt.subplots(1,2,figsize=(12,5.4),sharex=True,sharey=True)
    for ax,family,title in zip(axes,['poisson','nb2'],['Poisson','Binomial negativa NB2']):
        for j,suffix in enumerate(STRUCTURES):
            g=controlled[controlled.familia.eq(family)&controlled.estrutura.eq(LABELS[suffix])].sort_values(['lambda_fixo','lambda_grupos','lambda_curvatura'])
            for k,(_,r) in enumerate(g.iterrows()):
                yy=j+np.linspace(-.16,.16,len(g))[k]
                ax.scatter(r.dif_percentual,yy,s=45,color=COLORS.get(float(r.lambda_curvatura),'#555555'),edgecolor='white',lw=.5)
        ax.axvline(0,color='#444444',lw=1,ls='--');ax.grid(axis='x',alpha=.18);ax.set_title(title)
        ax.set_xlabel('100 × (NLL GAM / NLL GLM − 1), em %')
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x,p:number(x,4)))
    axes[0].set_yticks(np.arange(4),[LABELS[s] for s in STRUCTURES]);axes[0].invert_yaxis()
    for value,color in COLORS.items():axes[1].scatter([],[],color=color,label='λ curvatura = '+number(value,2))
    axes[1].legend(loc='upper left',fontsize=8,frameon=False)
    fig.suptitle('Comparações internas com penalidades comuns iguais · 202001',fontsize=13)
    figsave(fig,out,'02_comparacoes_controladas_CV',
            'Cada ponto é uma combinação elegível, agregando os três folds pelo número de células.\n'
            'À esquerda de zero, GAM tem menor perda. São comparações dependentes, sem IC ou p-valor.')

    fig,axes=plt.subplots(1,2,figsize=(14,5.8),sharey=True)
    for ax,suffix in zip(axes,['_INTER','_INTER_GRUPOS']):
        a=cal[cal.modelo.eq('GLM'+suffix)&cal.familia.eq('nb2')&cal.particao.eq('exploratorio_202002')&cal.variavel.eq('REGIAO')].copy()
        b=cal[cal.modelo.eq('GAM'+suffix)&cal.familia.eq('nb2')&cal.particao.eq('exploratorio_202002')&cal.variavel.eq('REGIAO')].copy()
        g=a[['grupo','OE','exposicao']].merge(b[['grupo','OE']],on='grupo',suffixes=('_GLM','_GAM'),validate='one_to_one').sort_values('exposicao',ascending=False)
        x=np.arange(len(g))
        for model,color in [('GLM',BLUE),('GAM',ORANGE)]:ax.plot(x,g['OE_'+model],'.-',ms=5,lw=.8,color=color,label=model)
        ax.axhline(1,ls='--',color='#444444',lw=1)
        ax.set_xticks(x,g.grupo.astype(str),rotation=90,fontsize=7)
        ax.set_title(LABELS[suffix]+(' †' if 'GRUPOS' in suffix else ''));ax.set_xlabel('Regiões por exposição decrescente');ax.grid(axis='y',alpha=.18)
    axes[0].set_ylabel('Observado / esperado');axes[0].legend(frameon=False)
    fig.suptitle('Calibração regional dos modelos NB2 com interação · 202002',fontsize=13)
    figsave(fig,out,'03_calibracao_regional',
            'O/E > 1 indica subestimação dos sinistros. A comparação usa as mesmas regiões e observações.\n'
            '† Penalidades comuns diferentes no par com grupos; curvas não isolam o efeito da estrutura GAM.')

    fig,axes=plt.subplots(2,2,figsize=(11,7.5),sharex=True,sharey=True)
    for ax,suffix in zip(axes.flat,STRUCTURES):
        for model,color,style in [('GAM',ORANGE,'-'),('GLM',BLUE,'--')]:
            path=source/'tabelas'/f'ano_parcial_{model}{suffix}_nb2.csv'
            d=read(path).sort_values('ANO_MODELO')
            ax.plot(d.ANO_MODELO,d.log_razao,color=color,ls=style,lw=1.8,label=model)
        ax.axhline(0,color='#999999',lw=.5);ax.grid(alpha=.15)
        ax.set_title(LABELS[suffix]+(' †' if 'GRUPOS' in suffix else ''))
        ax.set_xlabel('Ano do modelo');ax.set_ylabel('Log da razão relativa a 2015')
    axes[0,0].legend(frameon=False)
    fig.suptitle('Efeito parcial do ano nos ajustes NB2 · treino em 202001',fontsize=13)
    figsave(fig,out,'04_efeito_parcial_ano',
            'Curvas condicionais; faixa de exibição 1996–2020. As linhas podem ficar sobrepostas.\n'
            '† Busca desigual no par com grupos. Sobreposição visual não constitui teste de equivalência.')

    fig,axes=plt.subplots(2,2,figsize=(12,8.2))
    for ax,col,title in zip(axes.flat,['MAE_contagem','MSE_contagem','RMSE_contagem','R2_contagem'],
                          ['MAE · menor é melhor','MSE · menor é melhor','RMSE · menor é melhor','R² convencional · maior é melhor']):
        y=np.arange(4)
        for prefix,color,offset in [('GLM',BLUE,-.17),('GAM',ORANGE,.17)]:
            bars=ax.barh(y+offset,[q.loc[prefix+s,col] for s in STRUCTURES],height=.30,color=color,label=prefix)
            for j,bar in enumerate(bars):
                if 'GRUPOS' in STRUCTURES[j]:bar.set_hatch('//');bar.set_edgecolor('white')
        ax.set_yticks(y,[LABELS[s]+(' †' if 'GRUPOS' in s else '') for s in STRUCTURES]);ax.invert_yaxis()
        ax.set_title(title,fontsize=11);ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x,p:number(x,2)))
        if col=='R2_contagem':ax.axvline(0,color='#444444',lw=1)
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.53,.94),ncol=2,frameon=False)
    fig.suptitle('Erros e R² das contagens · NB2 · avaliação exploratória 202002',fontsize=13)
    figsave(fig,out,'05_MAE_MSE_RMSE_R2',
            'R² usa como referência a média observada das contagens em 202002. Pode ser negativo.\n'
            '† Busca desigual no par com grupos. Todas as métricas usam as mesmas células; nenhuma exclusão adicional.',top=.90)


def table_html(df,formats=None):
    q=df.copy();formats=formats or {}
    for col in q.columns:
        if col in formats:q[col]=q[col].map(lambda x:number(x,formats[col]))
    return '<div class="tablewrap">'+q.to_html(index=False,escape=True,border=0,na_rep='Não disponível')+'</div>'


def report(source,out,metrics,pairs,controlled,cal,edf,candidates,manifest):
    m=metrics[metrics.familia.eq('nb2')&metrics.particao.eq('exploratorio_202002')&metrics.modelo.ne('NULO')].copy()
    rows=m[['modelo','nll_por_celula','poisson_deviance_por_exposicao','OE','RMSE_contagem','MAE_contagem']]
    rows=rows.rename(columns={'modelo':'Modelo','nll_por_celula':'NLL/célula','poisson_deviance_por_exposicao':'D. Poisson/exposição',
                             'RMSE_contagem':'RMSE','MAE_contagem':'MAE'})
    main_table=table_html(rows,{x:(9 if x=='NLL/célula' else 6) for x in rows if x!='Modelo'})
    errors=m[['modelo','MAE_contagem','MSE_contagem','RMSE_contagem','R2_contagem']].copy()
    errors.columns=['Modelo','MAE','MSE','RMSE','R² convencional']
    error_table=table_html(errors,{x:6 for x in errors if x!='Modelo'})
    d=pairs[pairs.familia.eq('nb2')][['estrutura','nll_por_celula_dif_percentual','poisson_deviance_por_exposicao_dif_percentual',
                    'RMSE_contagem_dif_percentual','MAE_contagem_dif_percentual','penalidades_comuns_iguais']].copy()
    d.columns=['Estrutura','Δ NLL (%)','Δ deviance (%)','Δ RMSE (%)','Δ MAE (%)','Penalidades comuns iguais']
    d['Penalidades comuns iguais']=d['Penalidades comuns iguais'].map({True:'Sim',False:'Não'})
    delta_table=table_html(d,{x:6 for x in d if x.startswith('Δ')})
    cv=controlled.groupby(['estrutura','familia'],sort=False).agg(combinacoes=('comparacao','size'),
            menor_delta_pct=('dif_percentual','min'),maior_delta_pct=('dif_percentual','max')).reset_index()
    cv.columns=['Estrutura','Família','Combinações','Menor Δ NLL (%)','Maior Δ NLL (%)']
    cv_table=table_html(cv,{'Menor Δ NLL (%)':6,'Maior Δ NLL (%)':6})
    src=metrics[metrics.modelo.eq('NULO')&metrics.familia.eq('poisson')][['particao','n','exposicao','sinistros','frequencia_observada']]
    src=src.rename(columns={'particao':'Partição','n':'Células','exposicao':'Exposição','sinistros':'Sinistros','frequencia_observada':'Sinistros/exposição'})
    src_table=table_html(src,{'Células':0,'Exposição':4,'Sinistros':0,'Sinistros/exposição':6})
    final=m.set_index('modelo');a=final.loc['GLM_INTER'];b=final.loc['GAM_INTER']
    region=cal[cal.modelo.eq('GLM_INTER')&cal.familia.eq('nb2')&cal.particao.eq('exploratorio_202002')&cal.variavel.eq('REGIAO')]
    failed=manifest['validacao']['ajustes_nao_convergentes']
    selected_count=manifest['validacao']['modelos_finais']
    img=lambda name,caption:'<figure><img src="data:image/png;base64,'+base64.b64encode((out/'figuras'/f'{name}.png').read_bytes()).decode()+'"><figcaption>'+caption+'</figcaption></figure>'
    draft=(
        'Nos experimentos realizados, não foi demonstrada superioridade preditiva das especificações GAM avaliadas em relação às referências GLM. '
        'Na avaliação temporal exploratória de 202002, os modelos binomiais negativos sem efeitos de grupo apresentaram perdas logarítmicas praticamente coincidentes, '
        'com diferenças relativas de 0,000211% na estrutura aditiva e 0,000081% na estrutura com interação SEXO × IDADE, desfavoráveis aos GAMs. '
        'Nas comparações internas que mantiveram iguais as penalizações dos componentes comuns, inclusive nas estruturas com grupos, '
        'as diferenças também foram pequenas e variaram de sinal. '
        'Os GAMs com grupos selecionados apresentaram perdas temporais maiores, porém essa comparação foi limitada pela cobertura desigual da busca de hiperparâmetros. '
        'Assim, os resultados não sustentam uma vantagem preditiva consistente da abordagem GAM no desenho adotado. '
        'A proximidade observada em parte das comparações é descritiva: não foi realizado teste formal de diferença ou equivalência, '
        'e não se conclui igualdade estatística entre as classes de modelos.'
    )
    css='''body{font-family:Georgia,"Times New Roman",serif;color:#202b34;background:#edf1f3;margin:0;line-height:1.55}main{max-width:1080px;margin:30px auto;background:white;padding:46px 56px}h1,h2,h3{font-family:Arial,sans-serif;line-height:1.2;color:#214b67}h1{font-size:30px}h2{font-size:22px;margin-top:35px}h3{font-size:17px}p,li{font-size:16px}.sub{color:#53616b}.note{border-left:4px solid #cf6b35;background:#fff8ef;padding:14px 18px}.conclusion{border-left:4px solid #24547a;background:#f0f5f9;padding:18px 22px}.tablewrap{overflow-x:auto}table{border-collapse:collapse;width:100%;font:13px Arial,sans-serif;margin:16px 0}th{background:#24547a;color:white;text-align:left;padding:9px}td{padding:8px;border-bottom:1px solid #dce3e7}tr:nth-child(even){background:#f6f8f9}figure{margin:26px 0}img{width:100%;height:auto}figcaption{font-size:13px;color:#53616b}code{font-size:13px;background:#edf1f3;padding:2px 4px}a{color:#24547a}.small{font-size:13px}@media print{body{background:white}main{max-width:none;margin:0;padding:0}h2{break-after:avoid}figure,table,.conclusion{break-inside:avoid}p{orphans:3;widows:3}@page{size:A4;margin:16mm}}'''
    body=f'''<h1>GLM e GAM na previsão de sinistros de perda parcial</h1>
<p class="sub">Consolidação dos experimentos SUSEP 2020 · versão 0.3 · resultados já executados</p>
<div class="conclusion"><strong>Conclusão empírica:</strong> não foi demonstrada vantagem consistente das especificações GAM avaliadas.
A proximidade de algumas métricas é descritiva. Equivalência estatística não foi demonstrada.</div>
<h2>1. Pergunta e alcance do experimento</h2>
<p>A pergunta é se a especificação GAM com efeitos de grupo melhora a previsão de sinistros de perda parcial em relação às referências GLM.
A resposta é <code>FREQ_SIN2</code>, contagem de sinistros de colisão parcial, com <code>log(EXPOSICAO1)</code> como offset.
As linhas são células agregadas da base pública, não contratos nem condutores identificados. A análise mantém exposição positiva, J, categorias especiais e extremos.</p>
<p>O termo não linear desta implementação é a spline natural de <code>ANO_MODELO</code>; IDADE permanece categórica.
“Com grupos” significa efeitos penalizados de REGIAO e COD_MODELO, com interpretação MAP condicional.
Não se estimaram uma distribuição marginal completa dos efeitos, REML ou ICC. Os resultados se referem a essas especificações concretas.</p>
{src_table}
<p>A seleção usou três folds em 202001, agrupados por chave de características da célula, e até 250 mil linhas de treino por fold.
Os folds de validação são completos. 202002 foi consultado nas revisões do projeto e deve ser apresentado como avaliação temporal exploratória.</p>
<h2>2. Resultados temporais dos modelos selecionados</h2>
<p>A tabela principal mostra NB2. Poisson, modelos nulos, treino, demais métricas e parâmetros estão nos CSVs completos.
Esta apresentação de NB2 não transforma a escolha da família em uma decisão prospectiva: todas as alternativas executadas são preservadas.</p>
{main_table}
<p>NLL é a log-verossimilhança negativa por célula; menor é melhor. Deviance Poisson/exposição usa uma referência comum para erro de média.
O/E é observado dividido por esperado; a referência é 1. RMSE e MAE aqui se referem à contagem por célula.</p>
<h3>MAE, MSE, RMSE e R² convencional</h3>
{error_table}
<p>MAE e RMSE já estavam na execução original. MSE = RMSE². O R² convencional foi acrescentado usando
<code>R² = 1 − SSE / SST</code>, com <code>SSE = n × RMSE²</code> e <code>SST = Σy² − (Σy)²/n</code>.
A soma Σy² foi recuperada da auditoria anterior do mesmo recorte e conferida contra a tabela de dispersão e os totais da versão 0.3.
Não são métricas de uma amostra, nem pseudo-R², nem R² ajustado.</p>
<p>O R² tem como referência a previsão constante igual à média observada das contagens no período avaliado.
R² negativo indica erro quadrático maior que essa referência. O modelo nulo com offset varia com a exposição,
portanto seu R² convencional não precisa ser zero. R² em torno de 0,029 significa redução de aproximadamente 2,9% da soma de erros quadráticos
em relação à média; não significa “2,9% de acerto”. Essas métricas são sensíveis às células extremas e complementam NLL, deviance e calibração.</p>
<p><strong>MAPE:</strong> sua fórmula usual divide cada erro absoluto pelo valor observado.
Em 202002, {number(float(m.zeros_observados.iloc[0]),0)} de {number(float(m['n'].iloc[0]),0)} células têm zero sinistro
({number(float(m.percentual_celulas_zero.iloc[0]),2)}%). Por isso o MAPE é registrado como indefinido,
com motivo explícito, sem excluir zeros ou substituí-los por um número pequeno para produzir uma métrica artificialmente finita.
A documentação do scikit-learn alerta que seu tratamento numérico dos zeros pode retornar valores arbitrariamente grandes.</p>
<p>A tabela <code>10_metricas_solicitadas.csv</code> inclui também WAPE como medida agregada complementar:
<code>100 × Σ|y − μ| / Σy</code>. WAPE aceita células com zero quando o total de sinistros é positivo e pode ultrapassar 100%.
Não é MAPE, não representa percentual de células erradas e não substitui a análise de calibração.</p>
{delta_table}
<p>Δ percentual = 100 × (métrica GAM / métrica GLM − 1). Para as métricas de perda, Δ positivo favorece o GLM.
O/E não é interpretado por essa regra: sua distância de 1 é que importa.</p>
<div class="note"><strong>Limite da comparação com grupos:</strong> o sorteio da versão 0.3 deixou os GAMs com grupos sem avaliar a penalidade fixa 0,0001,
selecionada pelos GLMs correspondentes. As perdas 6,97% e 5,57% maiores descrevem esses ajustes, mas não isolam uma inferioridade da classe GAM.
Tampouco podem ser descritas como igualdade ou equivalência entre os modelos multinível.</div>
{img('01_avaliacao_temporal_NB2','Figura 1. Ajustes NB2 selecionados. As estruturas com grupos têm cobertura desigual das penalizações.')}
<h2>3. Comparações internas sob penalidades comuns iguais</h2>
<p>Para aproveitar os experimentos existentes, foram pareadas todas as configurações elegíveis de GLM e GAM com a mesma família,
estrutura, penalidade fixa, penalidade dos grupos e partições. Só a curvatura difere.
São {len(controlled)} comparações de configurações, cada uma com três folds, e não {len(controlled)} experimentos independentes.
A NLL é agregada pela soma das perdas dividida pela soma do número de células de validação.</p>
{cv_table}
<p>Esses intervalos representam o mínimo e o máximo entre configurações efetivamente executadas. Não são intervalos de confiança.
A maior redução observada da NLL foi {number(-controlled.dif_percentual.min(),6)}% e a maior elevação foi {number(controlled.dif_percentual.max(),6)}%.
Há diferenças nos dois sentidos. Não foi selecionado apenas o par que favorece uma classe.</p>
<p>Nos pares com grupos, a penalidade fixa comum disponível é 0,01. A conclusão de proximidade fica condicionada a essa regularização;
os pares não cobrem a penalidade fixa 0,0001 selecionada pelos GLMs. A curvatura fortemente penalizada também pode se aproximar do componente linear por construção.</p>
{img('02_comparacoes_controladas_CV','Figura 2. Diferenças internas pareadas. Cada ponto usa os mesmos folds e penalidades comuns para GLM e GAM.')}
<h2>4. Calibração e forma dos efeitos</h2>
<p>No GLM_INTER NB2, foram observados {number(a.sinistros,0)} sinistros e previstos {number(a.previstos,2)}, com O/E={number(a.OE,6)}.
O GAM_INTER NB2 previu {number(b.previstos,2)}, com O/E={number(b.OE,6)}.
Ambos apresentam subestimação no semestre de avaliação. Em {int(region.OE.gt(1).sum())} de {len(region)} regiões, o GLM_INTER NB2 teve O/E acima de 1.</p>
<p>Proximidade de perdas entre dois modelos não garante boa calibração absoluta. A concentração dos erros em poucas células também exige que RMSE seja lido junto de NLL, deviance e O/E.</p>
{img('03_calibracao_regional','Figura 3. Calibração regional integral. Cada região inclui todas as células do recorte correspondente.')}
{img('04_efeito_parcial_ano','Figura 4. Efeitos parciais na escala do preditor logarítmico. Uma reta nessa escala corresponde ao componente linear do GLM.')}
{img('05_MAE_MSE_RMSE_R2','Figura 5. Métricas convencionais da contagem. As restrições de comparabilidade dos modelos com grupos permanecem.')}
<p>Os EDF condicionais da curvatura nos GAMs sem grupos são muito próximos de zero.
Nos modelos com grupos, a covariância/EDF não foi computada devido ao limite de tamanho configurado.
Um EDF indisponível não foi preenchido com zero. A tabela <code>08_complexidade_EDF.csv</code> distingue esses casos.</p>
<h2>5. O que as hipóteses permitem afirmar</h2>
<p>Defina d = perda preditiva esperada do GAM − perda preditiva esperada do GLM.
Uma hipótese direcional de superioridade seria H₀: d ≥ 0, contra H₁: d &lt; 0.
Os valores apresentados estimam diferenças no experimento; não constituem, sozinhos, um teste de H₀.</p>
<p>Mesmo um teste de diferença não significativo não demonstraria equivalência.
Para equivalência prática, seria necessário justificar uma margem ε, com H₀: d ≤ −ε ou d ≥ ε e H₁: −ε &lt; d &lt; ε,
e quantificar a incerteza por um procedimento compatível com as dependências e a seleção dos modelos.
Não definimos ε a partir das diferenças já vistas. Lakens (2017) apresenta a distinção entre ausência de significância e evidência de equivalência.</p>
<p><strong>Não foi executado teste formal de diferença ou equivalência, e nenhum p-valor é reportado.</strong>
Os três folds reutilizam conjuntos de treino sobrepostos e participam da seleção; não foram tratados como três repetições independentes para um teste t ingênuo.
As tabelas agregadas não fornecem, por si sós, a variância da diferença pareada de perdas na população-alvo.</p>
<table><thead><tr><th>Afirmação</th><th>Alcance permitido</th></tr></thead><tbody>
<tr><td>A superioridade GAM foi demonstrada?</td><td>Não foi demonstrada nos experimentos e especificações avaliados.</td></tr>
<tr><td>Há métricas numericamente próximas?</td><td>Sim, nos pares descritos nas seções 2 e 3, sob suas condições específicas.</td></tr>
<tr><td>GLM é estatisticamente superior?</td><td>Não estabelecido por teste formal.</td></tr>
<tr><td>H₀ foi aceita ou não rejeitada por um teste?</td><td>Não há teste formal executado que sustente essa descrição.</td></tr>
<tr><td>GLM e GAM multinível são estatisticamente equivalentes?</td><td>Não demonstrado.</td></tr></tbody></table>
<h2>6. Texto sugerido para resultados e conclusão</h2>
<div class="conclusion">{draft}</div>
<p>O texto documenta um resultado empírico sem transformar um resultado inconclusivo sobre superioridade em evidência de equivalência.</p>
<h2>7. Reprodutibilidade e integridade</h2>
<p>Foram conferidos {selected_count} ajustes finais convergentes e {manifest['validacao']['particoes_reconciliadas']} partições de diagnóstico.
Na CV original, {failed} de {manifest['validacao']['ajustes_cv']} ajustes não convergiram e não foram admitidos nos pares controlados.
A consolidação lê arquivos existentes, verifica hashes e recalcula somente tabelas e gráficos. Não importa bibliotecas de modelagem nem estima coeficientes.</p>
<p>O script <code>07_consolidar_resultados.py</code>, as fontes utilizadas e os CSVs acompanham o pacote.
<code>manifesto_consolidacao.json</code> registra hashes, versões, fórmulas, controles e tempo de execução.
A reprodução desta apresentação não substitui a preservação do pipeline original para reprodução dos ajustes estatísticos.</p>
<p class="small">Fonte empírica: revisao_20260926_205057_251095_para_enviar.zip, execução 0.3.0-detalhada.
Manifesto SHA-256: {EXPECTED}.</p>
<p class="small">Fonte adicional exclusiva das estatísticas de população para R²: resumo_integral.csv da auditoria anterior,
conferido com dispersao_marginal.csv. Ambos se referem à origem {json.loads((source/'manifesto.json').read_text(encoding='utf-8-sig'))['manifesto_origem_sha256']}.
As previsões e erros dos modelos antigos não foram reutilizados.</p>
<h2>Referência metodológica</h2>
<p>LAKENS, D. Equivalence Tests: A Practical Primer for t Tests, Correlations, and Meta-Analyses.
<em>Social Psychological and Personality Science</em>, 8(4), 355–362, 2017.
DOI: <a href="https://doi.org/10.1177/1948550617697177">10.1177/1948550617697177</a>.
<a href="https://pubmed.ncbi.nlm.nih.gov/28736600/">Registro e resumo do artigo</a>.
O artigo fundamenta a distinção inferencial, não fornece os resultados empíricos deste projeto.</p>'''
    body+='''<p>Documentação oficial das métricas:
<a href="https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html">R²</a> e
<a href="https://scikit-learn.org/stable/modules/generated/sklearn.metrics.mean_absolute_percentage_error.html">MAPE e valores observados iguais a zero</a>.</p>'''
    (out/'RELATORIO_RESULTADOS.html').write_text('<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Resultados GLM e GAM — SUSEP 2020</title><style>'+css+'</style></head><body><main>'+body+'</main></body></html>',encoding='utf-8')
    (out/'TEXTO_PARA_TCC.md').write_text('# Resultados e alcance da conclusão\n\n'+draft+'\n\n'
        'Não substituir essa redação por “H0 aceita”, “p > 0,05” ou “equivalência estatística demonstrada”: não foi executado teste que sustente essas afirmações.\n',encoding='utf-8')


def executar(source,out):
    start=time.perf_counter();source=Path(source).resolve();out=Path(out).resolve()
    if source==out or source in out.parents:raise ValueError('Escolha saida fora da pasta de fontes.')
    for folder in ['tabelas','figuras']:(out/folder).mkdir(parents=True,exist_ok=True)
    logging.basicConfig(level=logging.INFO,format='%(levelname)s %(message)s',handlers=[logging.StreamHandler(),logging.FileHandler(out/'consolidacao.log',mode='w',encoding='utf-8')],force=True)
    if sha(source/'manifesto.json')!=EXPECTED:raise ValueError('Manifesto difere da execucao auditada.')
    hashes={str(p.relative_to(source)).replace('\\','/'):sha(p) for p in sorted(source.rglob('*')) if p.is_file() and p.name!='HASHES_FONTES.json'}
    if (source/'HASHES_FONTES.json').exists():
        expected=json.loads((source/'HASHES_FONTES.json').read_text(encoding='utf-8'))
        if hashes!=expected:raise ValueError('Alguma fonte foi alterada. Preserve os arquivos recebidos.')
    metrics=read(source/'tabelas/comparacao_consolidada.csv')
    cv=read(source/'tabelas/validacao_interna.csv');selected=read(source/'tabelas/selecionados.csv')
    assert len(metrics)==36 and bools(metrics.convergiu).all()
    assert not metrics.duplicated(['modelo','familia','particao']).any()
    metrics,population=extended_metrics(metrics,source)
    pairs=paired_selected(metrics)
    candidates,controlled,folds=controlled_cv(cv)
    cal,checks,edf=diagnostics(source,metrics)
    totals=cal[cal.variavel.eq('TOTAL')][['modelo','familia','particao','erro_quadratico']]
    controls=metrics.merge(totals,on=['modelo','familia','particao'],validate='one_to_one')
    assert np.allclose(controls.MSE_contagem*controls['n'],controls.erro_quadratico,rtol=1e-10,atol=1e-7)
    assert len(controlled)==40 and len(folds)==120
    logging.info('Fontes conferidas; 40 comparacoes internas pareadas. Nenhum modelo sera ajustado.')
    for frame,name in [(metrics,'01_metricas_completas'),(selected,'02_modelos_selecionados'),(pairs,'03_pares_temporais'),
                       (controlled,'04_CV_controlada'),(folds,'05_CV_controlada_por_fold'),(candidates,'06_elegibilidade_CV'),
                       (cal,'07_calibracao_integral'),(edf,'08_complexidade_EDF'),(checks,'09_reconciliacao')]:
        save(frame,out/'tabelas'/f'{name}.csv')
    save(metrics[['modelo','familia','particao','n','MAE_contagem','MSE_contagem','RMSE_contagem','R2_contagem',
                  'MAPE_percentual','MAPE_situacao','WAPE_percentual','percentual_celulas_zero']],
         out/'tabelas/10_metricas_solicitadas.csv')
    save(population,out/'tabelas/11_referencia_populacao_R2.csv')
    make_figures(source,metrics,pairs,controlled,cal,out)
    manifest=dict(versao=VERSION,script_sha256=sha(Path(__file__)),manifesto_origem_sha256=EXPECTED,
                  fontes_sha256=hashes,python=platform.python_version(),
                  bibliotecas={p:importlib.metadata.version(p) for p in ['numpy','pandas','matplotlib']},
                  ajuste_de_novos_modelos=False,teste_formal_de_diferenca=False,teste_formal_de_equivalencia=False,
                  formulas=dict(diferenca_relativa_percentual='100*(GAM/GLM-1)',
                                NLL_CV='soma(nll_total_folds)/soma(n_validacao_folds)',
                                MSE='RMSE_contagem**2',R2='1 - n*MSE_contagem/(soma_y2-soma_y**2/n)',
                                MAPE='Indefinido pela presenca de zeros; nao calculado com epsilon.',
                                WAPE_percentual='100*n*MAE_contagem/soma_y'),
                  validacao=dict(modelos_finais=int(metrics[['modelo','familia']].drop_duplicates().shape[0]),
                      ajustes_cv=len(cv),ajustes_nao_convergentes=int((~bools(cv.convergiu)).sum()),
                      comparacoes_CV=len(controlled),particoes_reconciliadas=len(checks)))
    report(source,out,metrics,pairs,controlled,cal,edf,candidates,manifest)
    manifest['segundos_consolidacao']=time.perf_counter()-start
    manifest['saidas_sha256']={str(p.relative_to(out)).replace('\\','/'):sha(p) for p in sorted(out.rglob('*'))
                             if p.is_file() and p.name not in ['manifesto_consolidacao.json','consolidacao.log']}
    js(manifest,out/'manifesto_consolidacao.json')
    logging.info('Concluido em %.1f segundos. Abra %s',manifest['segundos_consolidacao'],out/'RELATORIO_RESULTADOS.html')
    return manifest


if __name__=='__main__':
    root=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description='Tabelas e graficos dos experimentos ja executados, sem modelagem.')
    parser.add_argument('--origem',default=str(root/'fontes_v03'))
    parser.add_argument('--saida',default=str(root/'resultados'))
    args,_=parser.parse_known_args()
    executar(args.origem,args.saida)
