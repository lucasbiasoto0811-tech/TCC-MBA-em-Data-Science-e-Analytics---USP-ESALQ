"""Verificacao independente de formulas e regularizacao; nao e resultado do TCC."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import sparse, optimize, stats
from sklearn.linear_model import PoissonRegressor
from estimacao import objective, logpmf, fit_count, covariance, Desenho


def verificar():
    rng=np.random.default_rng(2831)
    n=3000
    z=rng.normal(size=(n,3))
    x=sparse.csr_matrix(np.column_stack([np.ones(n),z]))
    e=rng.uniform(.05,3,n)
    true=np.array([-.8,.2,-.3,.1])
    mu=e*np.exp(x@true)
    y=rng.poisson(mu).astype(float)
    penalty=sparse.diags([0,.02,.02,.02],format='csr')
    results={}
    for family in ['poisson','nb2']:
        theta=np.r_[true,np.log(.6)] if family=='nb2' else true
        f=lambda t: objective(t,x,y,np.log(e),penalty,family)
        err=optimize.check_grad(lambda t:f(t)[0],lambda t:f(t)[1],theta)
        assert err<1e-5,(family,err)
        results['erro_gradiente_'+family]=float(err)
        a=.6 if family=='nb2' else 0
        ref=stats.nbinom.logpmf(y,1/a,1/(1+a*mu)) if family=='nb2' else stats.poisson.logpmf(y,mu)
        delta=float(np.max(abs(logpmf(y,mu,family,a)-ref)))
        assert delta<1e-10,delta
        results['erro_logpmf_'+family]=delta
    fit=fit_count(x,y,e,penalty,'poisson')
    assert fit.success,fit
    # Mesma funcao objetivo apos normalizacao: sklearn alpha=n*lambda/sum(E).
    sk=PoissonRegressor(alpha=n*.02/e.sum(),tol=1e-10,max_iter=1000).fit(z,y/e,sample_weight=e)
    diff=float(np.max(abs(fit.beta-np.r_[sk.intercept_,sk.coef_])))
    assert diff<1e-4,diff
    results['erro_coeficientes_vs_sklearn']=diff
    cov,edf,_=covariance(x,fit.predict(x,e),fit,penalty,100)
    assert 1<edf<4
    results['edf_poisson']=edf
    alpha=.7
    ynb=rng.negative_binomial(1/alpha,1/(1+alpha*mu)).astype(float)
    nb=fit_count(x,ynb,e,sparse.csr_matrix((4,4)),'nb2')
    assert nb.success,nb
    assert np.max(abs(nb.beta-true))<.15,nb.beta
    assert abs(nb.alpha-alpha)<.25,nb.alpha
    results['alpha_nb2_simulado']=alpha
    results['alpha_nb2_estimado']=nb.alpha
    # Categoria J com zero ocorrencias: coeficientes finitos e registros preservados.
    sexes=np.where(np.arange(n)%4==0,'J',np.where(np.arange(n)%3==0,'__NULL__','M'))
    df=pd.DataFrame(dict(COD_TARIF='1',SEXO=sexes,IDADE='0',COD_GRUPO='1',
        REGIAO=np.where(np.arange(n)%2==0,'1','2'),COD_MODELO='001',
        ANO_NUM=rng.integers(2000,2021,n).astype(float),ANO_STATUS='ANO_4_DIGITOS'))
    df.loc[:20,'ANO_NUM']=np.nan
    df.loc[:20,'ANO_STATUS']='ESPECIAL___NULL__'
    ys=y.copy();ys[sexes=='J']=0
    for kind in ['GLM','GAM','GLM_GRUPOS','GAM_GRUPOS']:
        d=Desenho(kind).fit(df)
        xx=d.transform(df)
        pp=d.penalty(.01,.01,.01)
        ff=fit_count(xx,ys,e,pp,'poisson')
        assert ff.success,(kind,ff)
        assert np.isfinite(ff.beta).all()
        assert len(ff.predict(xx,e))==n
        altered=df.iloc[:2].copy()
        altered.loc[:,'COD_MODELO']='NOVO'
        altered.loc[:,'SEXO']='NOVO'
        assert np.isfinite(ff.predict(d.transform(altered),e[:2])).all()
        results[kind+'_J_finito']=True
    path=Path(__file__).parent/'verificacao/calculos.json'
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results,indent=2))
    return results

if __name__=='__main__': verificar()
