# Execucao AUTOSEG — resultados condicionais

Versao: 0.2.0-modelagem-condicional. Modo amostra: False.

J mantido no principal. Nao interpretar zeros de J como ausencia real de risco.
Nenhuma conclusao automatica de superioridade GLM/GAM foi escrita.
Consulte comparacao_consolidada.csv, logs e todos os arquivos de status.
A selecao de lambdas usa somente a particao interna de 202001. 202002 nao escolhe lambdas.
A auditoria ja examinou marginais de ambos os semestres: teste temporal nao foi totalmente cego.
NB2 nao prova adequacao; residuos, zeros e calibracao podem continuar inadequados.
MAP de grupos nao substitui inferencia marginal/REML. ICC e variancias populacionais nao estimados.
EDF e intervalos locais ficam ausentes quando o limite de colunas e ultrapassado.
Intervalos condicionados a lambdas/alpha nao corrigem selecao nem dependencia residual.
Nao comparar AIC/deviance bruta entre principal e sensibilidade: populacoes diferentes.
O modelo nao estima o risco total removido por exclusao de celulas sem exposicao.

## Proxima revisao

Enviar tabelas/comparacao_consolidada.csv, selecionados_*.csv, selecao_*.csv,
tabelas/recorte.csv, execucao.log e as figuras de diagnostico dos candidatos.
Avaliacao formal de inflacao de zeros/hurdle requer mecanismo e diagnostico condicional;
nao e ativada por alta proporcao marginal de zeros. Nao ha esses modelos nesta versao.
Validacao de grupos inteiramente novos e bootstrap com reajuste permanecem extensoes.
Este pacote e uma primeira comparacao executavel; a inferencia final do TCC depende da revisao.