# Conferência das células na fonte original

A auditoria integral foi concluída e reconciliada. Leia RELATORIO_AUDITORIA_INTEGRAL.md
para os resultados e a justificativa da conferência adicional.

1. Copie `04_conferir_origem.py` e `04_celulas_verificar.csv` para a pasta
   `tcc_susep_modelagem`, junto de `config.json`.
2. Deixe `PASTA_EXECUCAO = ''`. O script procura a execução auditada pelo hash
   do manifesto, usando `pasta_saida` do seu config.json.
3. Confira que `pasta_dados` do config.json ainda aponta para os dois CSVs
   originais usados na modelagem. Eles serão somente lidos.
4. No terminal PowerShell aberto nessa pasta, execute:

```powershell
python .\04_conferir_origem.py
```

5. Envie o ZIP `conferencia_origem_....zip` indicado ao final.

Não é necessário executar novamente a modelagem ou a auditoria anterior.
Nenhum modelo será carregado ou ajustado. O script lê os arquivos em blocos,
preserva os valores textuais e cria uma pasta nova. Não edite os arquivos
originais: a verificação de hash precisa confirmar sua identidade.

Se os resultados foram movidos para outro local, preencha PASTA_EXECUCAO com
a pasta `execucao_...` que contém o manifesto original. Um erro por hash
significa que o arquivo encontrado não tem os mesmos bytes da fonte registrada;
não deve ser ignorado ou contornado mudando o hash esperado.

A conferência técnica deste script foi executada em dados sintéticos, incluindo
leitura em múltiplos blocos, divergência numérica e arquivo modificado. A leitura
dos CSVs completos depende da execução em sua máquina. Os resultados reais
analisados no relatório são os da auditoria integral enviada.
