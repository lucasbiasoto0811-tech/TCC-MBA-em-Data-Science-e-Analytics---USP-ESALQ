"""Conferencia dos casos identificados na auditoria integral, sem ajustar modelos.
Copie este script E 04_celulas_verificar.csv para a pasta de config.json.
No PowerShell: python .\04_conferir_origem.py
"""
from pathlib import Path
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import json
import zipfile
import numpy as np
import pandas as pd

PASTA_EXECUCAO = ''  # Opcional: pasta execucao_... da modelagem original.
MANIFESTO_ESPERADO = 'c05d9186e463d67978192739a7192196381731056279b94e1f814f437c01b0a5'
BLOCO = 100_000
CHAVE = ['COD_TARIF','REGIAO','COD_MODELO','ANO_MODELO','SEXO','IDADE']


def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def numero(texto):
    # Conversao independente da funcao numeric() da etapa 2.
    try:
        value=Decimal(str(texto).strip().replace(',','.'))
        return float(value) if value.is_finite() else np.nan
    except (InvalidOperation,ValueError):return np.nan


def codigo(texto,coluna):
    s=str(texto).strip()
    if s.upper() in {'','NULL','NA','N/A','NAN'}:return '__NULL__'
    if coluna!='COD_MODELO':
        n=numero(s)
        if np.isfinite(n) and n==int(n) and abs(n)<2**53:return str(int(n))
    return s


def salvar(df,p):
    df.to_csv(p,sep=';',decimal=',',index=False,encoding='utf-8-sig')


def executar(root=None):
    root=Path(root).resolve() if root else Path(__file__).resolve().parent
    cfg=json.loads((root/'config.json').read_text(encoding='utf-8-sig'))
    saida=Path(cfg['pasta_saida'])
    if not saida.is_absolute():saida=root/saida
    candidatos=[Path(PASTA_EXECUCAO).expanduser().resolve()] if PASTA_EXECUCAO else sorted(saida.glob('execucao_*'),reverse=True)
    execucao=next((p for p in candidatos if (p/'manifesto.json').is_file()
                   and sha(p/'manifesto.json')==MANIFESTO_ESPERADO),None)
    if execucao is None:
        raise FileNotFoundError('Execucao original nao localizada. Informe PASTA_EXECUCAO com a pasta que contem manifesto.json da modelagem auditada.')
    fontes=pd.read_csv(execucao/'tabelas/fontes.csv',sep=';',decimal=',',dtype=str)
    alvos=pd.read_csv(root/'04_celulas_verificar.csv',sep=';',decimal=',',dtype=str,keep_default_na=False)
    alvos['ID_LINHA']=alvos.ID_LINHA.astype('int64')
    if alvos.duplicated(['PERIODO','ID_LINHA']).any():raise ValueError('Alvos duplicados.')
    dados=Path(cfg['pasta_dados'])
    if not dados.is_absolute():dados=root/dados
    out=execucao/('conferencia_origem_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir()
    controles=[];extratos=[];hashes=[]
    for periodo,g in alvos.groupby('PERIODO',sort=True):
        path=dados/cfg['arquivos'][periodo]
        ref=fontes.loc[fontes.periodo.eq(periodo)].iloc[0]
        print(f'{periodo}: conferindo arquivo original...',flush=True)
        actual=sha(path)
        hashes.append(dict(periodo=periodo,arquivo=path.name,sha256=actual,confere=actual==ref.sha256))
        if actual!=ref.sha256:
            salvar(pd.DataFrame(hashes),out/'fontes_conferidas.csv')
            raise ValueError(f'Arquivo {path.name} difere daquele usado na modelagem. Nao e seguro localizar registros por ID_LINHA. Consulte fontes_conferidas.csv.')
        ids=set(g.ID_LINHA);by_id=g.set_index('ID_LINHA');offset=0;found=set()
        for raw in pd.read_csv(path,sep=';',encoding=ref.encoding,dtype=str,keep_default_na=False,chunksize=BLOCO):
            raw.columns=raw.columns.str.strip()
            pos=np.arange(offset,offset+len(raw),dtype=np.int64);offset+=len(raw)
            mask=np.isin(pos,list(ids))
            if not mask.any():continue
            picked=raw.loc[mask].copy();picked.index=pos[mask]
            for ident,row in picked.iterrows():
                t=by_id.loc[ident];y=numero(row.FREQ_SIN2);e=numero(row.EXPOSICAO1)
                checks={c:codigo(row[c],c)==str(t[c]) for c in CHAVE}
                checks['Y']=bool(np.isclose(y,numero(t.Y),rtol=0,atol=0))
                checks['E']=bool(np.isclose(e,numero(t.E),rtol=1e-12,atol=1e-12))
                controles.append(dict(PERIODO=periodo,ID_LINHA=int(ident),Y_AUDITORIA=numero(t.Y),
                    E_AUDITORIA=numero(t.E),Y_ORIGINAL_CONVERTIDO=y,E_ORIGINAL_CONVERTIDO=e,
                    **{c+'_confere':v for c,v in checks.items()},tudo_confere=all(checks.values())))
                found.add(int(ident))
            picked=picked.add_prefix('RAW_')
            picked.insert(0,'ID_LINHA',picked.index);picked.insert(0,'PERIODO',periodo)
            extratos.append(picked.reset_index(drop=True))
            # O hash ja verificou o arquivo inteiro; le somente ate o ultimo alvo.
            if found==ids:break
        if found!=ids:raise ValueError(f'Alvos nao localizados em {periodo}: {sorted(ids-found)}')
        print(f'{periodo}: {len(found)} celulas extraidas, com todas as colunas originais.',flush=True)
    controle=pd.DataFrame(controles)
    salvar(controle,out/'conferencia_celulas.csv')
    salvar(pd.concat(extratos,ignore_index=True),out/'celulas_originais_TEXTO.csv')
    salvar(pd.DataFrame(hashes),out/'fontes_conferidas.csv')
    meta=dict(status='CONCLUIDO' if controle.tudo_confere.all() else 'DIVERGENCIAS_REVISAR',
        celulas=len(controle),celulas_conferem=int(controle.tudo_confere.sum()),parametros_reestimados=False,
        dados_alterados=False,manifesto_origem_sha256=MANIFESTO_ESPERADO,
        script_sha256=sha(Path(__file__)),alvos_sha256=sha(root/'04_celulas_verificar.csv'))
    (out/'manifesto_conferencia.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'LEIA_RESULTADOS.txt').write_text('RAW_* preserva os valores textuais lidos de todas as colunas do CSV original.\n'
        'ID_LINHA e o indice zero-based do registro lido pelo pandas, sem o cabecalho; nao e necessariamente a linha fisica do arquivo.\n'
        'A concordancia confirma a importacao dos casos selecionados, nao a coerencia atuarial da informacao de origem.\n'
        'Nenhuma observacao foi excluida ou corrigida. Nenhum modelo foi reajustado.\n',encoding='utf-8')
    zip_path=out.with_suffix('.zip')
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):z.write(p,p.name)
    print('\nSTATUS:',meta['status'],'\nENVIE ESTE ARQUIVO:',zip_path)
    return out,zip_path


if __name__=='__main__':executar()
